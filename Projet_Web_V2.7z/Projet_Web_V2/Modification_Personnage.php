<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
include 'Creation_PersonnageClass.php';
include 'Modification_PersonnageClass.php';
include 'ConnexionClass.php';
session_start();
/*session is started if you don't write this line can't use $_Session  global variable*/
if (isset($_POST['textarea_connexion_pseudo']))
{
    $_SESSION["Pseudo"];
}
?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Modification_Personnage</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>                
                <ul>

                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_creation_personnage">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <div class="main2">
                <h1>Modification de Personnage : </h1>

                <div class="article_Modification_personnage_16000">
                    <?php
                    try
                    {
                        echo '<form action="Modification_Personnage.php" method="post">';
                            echo '<p>Nom du Personnage (*) : </p>';
                            echo '<input type="textarea" name="textarea_Modification_Personnage_Nom"><br>';
                            echo '<p>Prenom du Personnage (*) :</p>';
                            echo '<input type="textarea" name="textarea_Modification_Personnage_Prenom"><br>';
                            echo '<p>Sexe du Personnage (*) :</p>';
                            echo '<input type="textarea" name="textarea_Modification_Personnage_Sexe"><br>';
                            echo '<p>Age du Personnage (**) :</p>';
                            echo '<input type="textarea" name="textarea_Modification_Personnage_Age"><br>';  
                            echo '<p>Faction du Personnage (*) :</p>';
                            echo '<input type="textarea" name="textarea_Modification_Personnage_Faction"><br>';
                            echo '<p>Image du Personnage :</p>';
                            echo '<input type="textarea" name="textarea_Modification_Personnage_Image"><br><br>';
                            echo '<button type="submit" name="bouton_valider_inscription" value="Submit">Valider</button>';
                        echo '</form>';
                    }
                    catch (Exception $ex) 
                    {
                        echo '<br/>Erreur dans le formulaire de modification.';
                        die('Erreur : '.$ex->getMessage());
                    }
                    ?>
                    <p>(*) : Champ obligatoire !</p>
                    <p>(**) : Veuillez entrer un âge compris entre 4 et 110 ans ou bien celui-ci sera mis à zéro !</p>
                </div> <!--fermeture div article_Modification_personnage_16000-->
                    <?php
                       try
                        {                  
                            if(isset($_POST["textarea_Modification_Personnage_Nom"]) && ($_POST["textarea_Modification_Personnage_Prenom"])
                            && ($_POST["textarea_Modification_Personnage_Faction"]) && ($_POST["textarea_Modification_Personnage_Sexe"])) 
                            {
                                if (($_POST["textarea_Modification_Personnage_Sexe"] == "Masculin") || ($_POST["textarea_Modification_Personnage_Sexe"] == "Feminin"))
                                {
                                    $modificationPersonnage = new ManagerClass($base);
                                    $modification = new Modification_PersonnageClass();
                                    $modification->setNomModifiePersonnage(htmlentities(addslashes($_POST["textarea_Modification_Personnage_Nom"]), ENT_QUOTES));
                                    $modification->setPrenomModifiePersonnage(htmlentities(addslashes($_POST["textarea_Modification_Personnage_Prenom"]), ENT_QUOTES));
                                    $modification->setSexeModifiePersonnage(htmlentities(addslashes($_POST["textarea_Modification_Personnage_Sexe"]), ENT_QUOTES));
                                    $modification->setAgeModifiePersonnage(htmlentities(addslashes($_POST["textarea_Modification_Personnage_Age"]), ENT_QUOTES));
                                    $modification->setImageModifiePersonnage(htmlentities(addslashes($_POST["textarea_Modification_Personnage_Image"]), ENT_QUOTES));
                                    $modification->setPseudoModifiePersonnage($_SESSION['Pseudo']);
                                    $modification->setFactionModifiePersonnage(htmlentities(addslashes($_POST["textarea_Modification_Personnage_Faction"]), ENT_QUOTES));
                                    $modificationPersonnage->ModificationPersonnage($base, $modification);
                                }
                            } else {
                                echo '<br/>Veuillez au moins remplir tous les champs obligatoire.<br/>';
                            }                            
                        } 
                        catch (Exception $ex) 
                        {
                            echo '<br/>Erreur dans la fonction de modification.';
                            die('Erreur : '.$ex->getMessage());
                        }                      
                    ?> 
                <hr>

                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </div><!--fermeture div main2-->

            <footer>
                test footer                
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>