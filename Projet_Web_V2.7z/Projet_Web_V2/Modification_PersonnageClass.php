<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Creation_PersonnageClass
 *
 * @author thork
 */
class Modification_PersonnageClass 
{
    //attributs
    private $_nom_modifie_personnage;
    private $_prenom_modifie_personnage;
    private $_sexe_modifie_personnage;
    private $_age_modifie_personnage;
    private $_faction_modifie_personnage;
    private $_image_modifie_personnage;
    private $_pseudo_modifie_personnage;
    private $_territoire_modifie_personnage;
    private $_id_faction;
    
    //accesseurs
    public function getNomModifiePersonnage() 
    {
        return $this->_nom_modifie_personnage;
    }
    
    public function setNomModifiePersonnage($_nom_modifie_personnage) 
    {
        $this->_nom_modifie_personnage = $_nom_modifie_personnage;
    }
    
    public function getPrenomModifiePersonnage() 
    {
        return $this->_prenom_modifie_personnage;
    }
    
    public function setPrenomModifiePersonnage($_prenom_modifie_personnage) 
    {
        $this->_prenom_modifie_personnage = $_prenom_modifie_personnage;
    }
    
    public function getSexeModifiePersonnage() 
    {
        return $this->_sexe_modifie_personnage;
    }
    
    public function setSexeModifiePersonnage($_sexe_modifie_personnage) 
    {
        $this->_sexe_modifie_personnage = $_sexe_modifie_personnage;
    }
    
    public function getAgeModifiePersonnage() 
    {
        return $this->_age_modifie_personnage;
    }
    
    public function setAgeModifiePersonnage($_age_modifie_personnage) 
    {
        if (($_age_modifie_personnage > 4) && ($_age_modifie_personnage < 110))
        {
            $this->_age_modifie_personnage = (integer)$_age_modifie_personnage;
        } else {            
            $_age_modifie_personnage = NULL;
            $this->_age_modifie_personnage = (integer)$_age_modifie_personnage;
        }
    }   
    
    public function getImageModifiePersonnage()
    {
        return $this->_image_modifie_personnage;
    }
    
    public function setImageModifiePersonnage($_image_modifie_personnage)
    {
        $this->_image_modifie_personnage = $_image_modifie_personnage;
    }
    
    public function getPseudoModifiePersonnage()
    {
        return $this->_pseudo_modifie_personnage;
    }
    
    public function setPseudoModifiePersonnage($_pseudo_modifie_personnage)
    {
        $this->_pseudo_modifie_personnage = $_pseudo_modifie_personnage;
    }
    
        public function getFactionModifiePersonnage()
    {
        return $this->_faction_modifie_personnage;
    }
    
    public function setFactionModifiePersonnage($_faction_modifie_personnage)
    {
        $this->_faction_modifie_personnage = $_faction_modifie_personnage;
    }
    
    public function getTerritoireModifiePersonnage()
    {
        return $this->_territoire_modifie_personnage;
    }
    
    public function setTerritoireModifiePersonnage($_territoire_modifie_personnage)
    {
        $this->_territoire_modifie_personnage = $_territoire_modifie_personnage;
    }
    
    public function getIdFaction()
    {
        return $this->_id_faction;
    }
    
    public function setIdFaction($_id_faction)
    {
        $this->_id_faction = (integer)$_id_faction;
    }
}
