<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
include 'Creation_PersonnageClass.php';
session_start();
/*session is started if you don't write this line can't use $_Session  global variable*/
if (isset($_POST['textarea_connexion_pseudo']))
{
    $_SESSION["Pseudo"];
}
?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Supprimer_Personnage</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>                
                <ul>

                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_creation_personnage">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <div class="main2">
                <div class="article_Supprimer_personnage_15000">
                    <h1>Suppimer un Personnage : </h1>

                    <?php
                    echo 'Veuillez entrer le nom et le prenom du personnage que vous souhaitez effacer';
                        echo '<form action="Supprimer_Personnage.php" method="post">';
                            echo '<p>Nom du Personnage (*) :</p>';
                            echo '<input type="textarea" name="textarea_Supprimer_Personnage_Nom"><br>';
                            echo '<p>Prenom du Personnage (*) :</p>';
                            echo '<input type="textarea" name="textarea_Supprimer_Personnage_Prenom"><br>';
                            echo '<p>(*) : Champ obligatoire !</p>';
                            echo '<button type="submit" name="bouton_valider_inscription" value="Submit">Valider</button>';
                        echo '</form>';
                            try
                            {
                                if(isset($_POST["textarea_Supprimer_Personnage_Nom"]) && ($_POST["textarea_Supprimer_Personnage_Prenom"])) 
                                {
                                    $supprimerPersonnage = new ManagerClass($base);
                                    $supprimer = new Creation_PersonnageClass();
                                    $supprimer->setNomPersonnage(htmlentities(addslashes($_POST["textarea_Supprimer_Personnage_Nom"]), ENT_QUOTES));
                                    $supprimer->setPrenomPersonnage(htmlentities(addslashes($_POST["textarea_Supprimer_Personnage_Prenom"]), ENT_QUOTES));
                                    $supprimerPersonnage = new ManagerClass($base);
                                    $supprimerPersonnage->SupprimerPersonnages($base, $supprimer);
                                } else {
                                    echo 'Veuillez entrer le nom et le prenom du personnage que vous souhaitez effacer';
                                }
                            } 
                            catch (Exception $ex) 
                            {
                                echo '<br/>Erreur dans la fonctions suppression.';
                                die('Erreur : '.$ex->getMessage());
                            }                        
                        ?> 
                    <hr>
                </div><!--fermeture div article_Supprimer_personnage_15000-->

                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </div><!--fermeture div main2-->

            <footer>
                test footer                
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>
