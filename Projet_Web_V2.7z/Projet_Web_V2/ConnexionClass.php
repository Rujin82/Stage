<?php
require 'Manager/ConnexionBDD.php';

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ConnexionClass
 *
 * @author thork
 */
class ConnexionClass 
{
    // Déclaration des attributs
    private $_pseudo_connexion;
    private $_mdp_connexion;
    private $_hash;
    private $_id_pseudo;

    //accesseurs
    public function getPseudoConnexion() 
    {
        return $this->_pseudo_connexion; //retourne le _pseudo_connexion
    }
    
    public function setPseudoConnexion($_pseudo_connexion) 
    {
        $this->_pseudo_connexion = $_pseudo_connexion; //écrit dans l’attribut _pseudo_connexion
    }
    
    public function getMdpConnexion() 
    {
        return $this->_mdp_connexion; //retourne le _mdp_connexion
    }
    
    public function setMdpConnexion($_mdp_connexion) 
    {
        $this->_mdp_connexion = $_mdp_connexion; //écrit dans l’attribut _mdp_connexion
    }
    
    public function getHash()
    {
        return $this->_hash;
    }
    
    public function setHash($_hash)
    {
        $this->_hash = $_hash;
    }
    
    public function getIdPseudo()
    {
        return $this->_id_pseudo;
    }
    
    public function setIdPseudo($_id_pseudo)
    {
        $this->_id_pseudo = (integer)$_id_pseudo;
    }
}

