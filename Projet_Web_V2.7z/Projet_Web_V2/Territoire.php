<?php
require 'Manager/ConnexionBDD.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $_SESSION["Pseudo"];
}
?>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Territoire</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>
                <ul>                    
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_territoire">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <aside>
                <form action="Recherche.php" method="post">
                    <div class="recherche">RECHERCHE :<br>
                        <div class="rech_radio">
                            <input type="radio" name="choix" value="Bouton_Radio_Faction" checked> Faction<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Territoire"> Territoire<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Declin"> Année de déclin
                        </div> <!--fermeture div rech_radio-->
                        <input type="textarea" name="textarea_recherche1"></input><br>
                    <button type="submit" name="valider1" value="Submit">Valider</button>
                </form>
                </div> <!--fermeture div recherche-->
                <ul>
                    <li><strong><a href="#article_Territoire_4000">L'époque Sengoku : </a></strong></li>
                    <li><strong><a href="#article_Territoire_4100">Le Japon féodal est divisé en 7 régions : </a></strong></li>
                    <li><strong><a href="#article_Territoire_4200">Subdivisé en 63 provinces : </a></strong></li>
                    <li><strong><a href="#article_Territoire_4300">Provinces d'origines : </a></strong></li>
                </ul>               
            </aside>

            <main>
                <div class="article_Territoire_4000">
                    <h1 id="article_Territoire_4000">L'époque Sengoku : </h1>
                    <p>Ainsi s'ouvre la période d'Azuchi Momoyama. Le général Oda Nobunaga à la tête de la famille Oda 
                       et du clan Nobunaga entreprend l'unification du Japon qu'il n'achèvera pas. 
                       Le 21 juin 1582, il s'arrêta dans le temple du Honnō-ji. Il avait prévu d'aller appuyer un de ses vassaux, 
                       Hideyoshi, il est victime d'une trahison de Mitsuhide Akechi autre vassal important des Oda. 
                       Hideyoshi alors revient en vitesse et défait les forces de Mitsuhide à la bataille de Yamazaki. 
                       Il s'oppose aussi à Shibata Katsuie, principal vassal des Oda pour la succession du territoire conquis, 
                       et le vainc en 1583, toutes les affaires importantes passant alors sous son contrôle. La plupart des vassaux se soumettent au nouveau shogûn. 
                       Ieyasu lui s'oppose a Hideyoshi mais finalement se soumet aussi et ainsi Kinoshita termina d'unifier le Japon. À la mort de ce dernier, 
                       Ieyasu se révoltera contre Hideyori Toyotomi fils de Hideyoshi Toyotomi et les deux partis s'affrontent à la bataille de Sekigahara. 
                       Ieyasu Tokugawa en sort vainqueur et établit la lignée des shogûns Tokugawa. 
                       Ainsi commence l'ère Edo (nouvelle capitale) et se termine le Japon féodal.</p>
                <div class="up"><a href="#">(Up)</a></div>
                </div> <!--fermeture div article_Territoire_4000-->

                <div class="article_Territoire_4100">
                    <h2 id="article_Territoire_4100">Le Japon féodal est divisé en 7 régions : </</h2>
                    <ul>
                            <li>Le Hokuriku, au Nord-Ouest de l'île principale.</li>
                            <li>Le Tôkai, au Nord-Est du Japon.</li>
                            <li>Le Tôsan, entre le Hokuriku et le Tôkai.</li>
                            <li>Le San'in, dans le Nord de la grande île.</li>
                            <li>Le Nankai, (Shikoku) dans le sud de la grande île.</li>
                            <li>Le San'yo, entre le San'in et le Nankai.</li>
                            <li>Le Saikai (Kyûshû).</li>
                    </ul>
                </div> <!--fermeture div article_Territoire_4100-->
                <div class="up"><a href="#">(Up)</a></div>

                <div class="article_Territoire_4200">
                    <h2 id="article_Territoire_4200">et subdivisé en 63 provinces : <h2>
                        <ul>
                            <li>Province de Mutsu,</li>
                            <li>Province de Dewa,</li>
                            <li>Province d'Echigo,</li>
                            <li>Province de Shimotsuke,</li>
                            <li>Province de Hitachi,</li>
                            <li>Province de Kôzuke,</li>
                            <li>Province de Noto,</li>
                            <li>Province d'Etchû,</li>
                            <li>Province de Shinano,</li>
                            <li>Province de Musashi,</li>
                            <li>Province de Shimosa,</li>
                            <li>Province de Kaga,</li>
                            <li>Province de Kai,</li>
                            <li>Province de Sagami,</li>
                            <li>Province de Kazusa,</li>
                            <li>Province d'Awa,</li>
                            <li>Province d'Izu,</li>
                            <li>Province de Suruga,</li>
                            <li>Province d'Echizen,</li>
                            <li>Province de Mino,</li>
                            <li>Province d'Owari</li>
                            <li>Province de Mikawa,</li>
                            <li>Province de Tōtōmi,</li>
                            <li>Province de Wakasa,</li>
                            <li>Province de Tango,</li>
                            <li>Province de Tamba,</li>
                            <li>Province d'Ômi,</li>
                            <li>Province d'Iga,</li>
                            <li>Province d'Ise,</li>
                            <li>Province de Yamashiro,</li>
                            <li>Province de Kawachi,</li>
                            <li>Province de Kii,</li>
                            <li>Kansai,</li>
                            <li>Province d'Izumi,</li>
                            <li>Province de Yamato,</li>
                            <li>Province de Settsu,</li>
                            <li>Province de Harima,</li>
                            <li>Province d'Inaba,</li>
                            <li>Province de Tajima,</li>
                            <li>Province de Mimasaka,</li>
                            <li>Province de Bizen,</li>
                            <li>Province de Bitchû,</li>
                            <li>Province de Sanuki,</li>
                            <li>Province d'Awa,</li>
                            <li>Province de Tosa,</li>
                            <li>Province de Bingo,</li>
                            <li>Province de Hôki,</li>
                            <li>Province d'Izumo,</li>
                            <li>Province d'Iwami,</li>
                            <li>Province d'Aki,</li>
                            <li>Province d'Iyo,</li>
                            <li>Province de Tsushima,</li>
                            <li>Province de Nagato,</li>
                            <li>Province de Buzen,</li>
                            <li>Province de Bungo,</li>
                            <li>Province de Hyūga,</li>
                            <li>Province de Chikuzen,</li>
                            <li>Province de Hizen,</li>
                            <li>Province de Chikugo,</li>
                            <li>Province de Higo,</li>
                            <li>Province de Satsuma,</li>
                            <li>Province de Tsukushi.</li>
                        </ul>
                </div> <!--fermeture div article_Territoire_4200-->
                        <div class="up"><a href="#">(Up)</a></div>
                        <div class="source"><a href="https://fr.wikipedia.org/wiki/F%C3%A9odalit%C3%A9_au_Japon" target="_blank">source</a></div>

                <div class="article_Territoire_4300">
                    <h2 id="article_Territoire_4300">Provinces d'origines : </h2>
                        <h3>Chosokabe</h3>
                        <p>Province Tosa</p>

                        <h3>Date</h3>
                        <p>Province de Mutsu</p>

                        <h3>Hojo</h3>
                        <p>Province d'Ise</p>

                        <h3>Mori</h3>
                        <p>Province d'Aki</p>

                        <h3>Oda</h3>
                        <p>Province d'Owari</p>

                        <h3>Shimazu</h3>
                        <p>Province Satsuma et Osumi</p>

                        <h3>Takeda</h3>    
                        <p>Province Kai</p>

                        <h3>Uesugi</h3>
                        <p>Province Echigo</p>
                </div> <!--fermeture div article_Territoire_4300-->


                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </main>

            <footer>
                test footer                
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>