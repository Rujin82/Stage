<?php
require 'Manager/ConnexionBDD.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $_SESSION["Pseudo"];
}
//connexion à la base
//requete sql
//récupérer en tableau associatif
?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Faction</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

                <nav>
                    <ul>
                        <?php
                        if (isset($_SESSION["Pseudo"]))
                        { 
                            echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                            echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                            echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                            echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_faction">'
                            . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                        } else {
                            echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                            echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                            echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                        }
                        ?>
                    </ul>
                </nav>

            <aside>
                <form action="Recherche.php" method="post">
                    <div class="recherche">RECHERCHE :<br>
                        <div class="rech_radio">
                            <input type="radio" name="choix" value="Bouton_Radio_Faction" checked> Faction<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Territoire"> Territoire<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Declin"> Année de déclin
                        </div> <!--fermeture div rech_radio-->
                        <input type="textarea" name="textarea_recherche1"></input><br>
                        <button type="submit" name="valider1" value="Submit">Valider</button>
                    </div> <!--fermeture div recherche-->    
                </form>

                <ul><div class="clans">Les grands Clans : </div>
                    <li><strong><a href="#article_Faction_1000">Clan Chosokabe</a></strong></li>
                    <li><strong><a href="#article_Faction_1100">Clan Date</a></strong></li>
                    <li><strong><a href="#article_Faction_1200">Clan Hojo</a></strong></li>
                    <li><strong><a href="#article_Faction_1300">Clan Mori</a></strong></li>
                    <li><strong><a href="#article_Faction_1400">Clan Oda</a></strong></li>
                    <li><strong><a href="#article_Faction_1500">Clan Shimazu</a></strong></li>
                    <li><strong><a href="#article_Faction_1600">Clan Takeda</a></strong></li>
                    <li><strong><a href="#article_Faction_1700">Clan Uesugi</a></strong></li>
                </ul>
            </aside>

            <main>
                <h1>Les Clans Majeurs</h1>
                <div class="article_Faction_1000">
                    <h2 id="article_Faction_1000">Clan Chosokabe : </h2>
                    <p>Le clan Chōsokabe est une lignée de daimyos du Japon médiéval qui unifient l'île de Shikoku (en 1585) 
                       en combattant notamment le clan Miyoshi. Le clan est originaire de la province de Tosa et unifie celle-ci 
                       en 1575 grâce à Chōsokabe Motochika. Il perd cependant la province après la bataille de Sekigahara.</p>

                    <p>Dans la geste du clan Chōsokabe, le second daimyo, Chōsokabe Nobuchika, occupe une place de choix par la 
                       téméraire expédition navale qui le voit prendre en 1585 la forteresse d'Hitachi autrefois entre les mains du clan Hōjō. 
                       Les chroniqueurs décrivent un chef de guerre d'une fougue inédite, qui lui est fatale lors de la bataille de Shimosa, 
                       où il trouve la mort après avoir occis selon la légende plus de soixante samouraïs à lui seul.</p>

                    <div class="up"><a href="#">(Up)</a></div>
                    <div class="source"><a href="https://fr.wikipedia.org/wiki/Clan_Ch%C5%8Dsokabe" target="_blank">source</a></div>
                </div> <!--fermeture div article_Faction_1000-->

                <div class="artile_Faction_1100">
                    <h2 id="article_Faction_1100">Clan Date : </h2>
                    <p>Le clan Date (伊達氏) est une lignée de daimyos du Japon qui contrôlait une partie du nord du Japon à la fin du XVIe siècle 
                       et pendant la période Edo. Le membre le plus célèbre de ce clan est Masamune Date qui établit le pouvoir de la famille 
                       en vengeant la mort de son frère.</p>

                    <p>La famille descend des Fujiwara.</p> 

                    <p>Au début de la période Kamakura Tomomune Isa qui descend de Fujiwara no Uona (721-783) 
                       à la 16e génération, venait d'Isa dans la province d'Hitachi. Il s'installa dans le district de Date en 1189 et la famille 
                       prit le nom de ce district (qui se trouve dans l'actuelle préfecture de Fukushima). 
                       Ce district a été donné en récompense à la famille par Minamoto no Yoritomo, le premier shogun de la période Kamakura. 
                       Le shogun a donné cette terre en remerciement de leur participation à la guerre de Gempei.</p>

                    <p>Pendant la guerre de Nanboku-cho qui opposait deux cours impériales, le clan soutenait l'empereur Go-Daigo de la Cour du Sud 
                        contre Kitabake Akiie de la Cour impériale du Nord.</p>

                    <p>Pendant la période Sengoku, le clan essaya comme tous les autres d'unifier le pays. 
                       Il réussit à résister aux invasions de grands seigneurs de guerres comme Nobunaga Oda, Kenshin Uesugi, ou encore Hideyoshi Toyotomi. 
                       Cette résistance a réussi en partie grâce à Masamune Date qui tissa des alliances avec les autres clans du nord du Japon. 
                       Finalement, le clan Date choisit de soutenir Ieyasu Tokugawa en particulier à la bataille de Sekigahara. 
                       Cependant, après cette bataille, Ieyasu Tokugawa se rendit compte que le clan était une possible menace et essaya autant que possible 
                       d'éviter qu'il ne prenne trop d'importance.</p>

                    <p>En 1600, après que Masamune Date ait vaincu le clan Uesugi, le clan prit le contrôle des îles Uesugi dans la province de Mutsu 
                       et s'installa au château de la ville d'Iwatezawa qu'il renomma en Sendai.</p>

                    <div class="up"><a href="#">(Up)</a></div>
                    <div class="source"><a href="https://fr.wikipedia.org/wiki/Clan_Date" target="_blank">source</a></div>
                </div> <!--fermeture div article_Faction_1100-->

                <div class="article_Faction_1200">
                    <h2 id="article_Faction_1200">Clan Hojo : </h2>
                    <p>Le clan Hōjō (北条氏, hōjō shi?) est une famille de samouraïs qui a dominé la politique du Japon durant l'époque de Kamakura.</p>

                    <p>Descendants du clan Taira, ils ont pris leur nom de la petite ville de Hōjō, dans la province d'Izu. 
                       Lorsqu'en 1180 Minamoto no Yoritomo, gendre de Tokimasa Hōjō, alors chef du clan, sort de son exil pour combattre 
                       les Taira au cours de la guerre de Gempei, les Hōjō se rangent de son côté. Après la mort de Yoritomo, 
                       ils s'imposent auprès des shoguns suivants en tant que shikken (régents), et dominent de fait le gouvernement du Japon.</p>

                    <p>Le signe de ce clan a inspiré Nintendo pour créer le signe de la Triforce pour The Legend of Zelda.</p>

                    <div class="up"><a href="#">(Up)</a></div>
                    <div class="source"><a href="https://fr.wikipedia.org/wiki/Clan_H%C5%8Dj%C5%8D" target="_blank">source</a></div>
                </div> <!--fermeture div article_Faction_1200-->

                <div class="article_Faction_1300">
                    <h2 id="article_Faction_1300">Clan Mori : </h2>
                    <p>Le clan Mōri (毛利氏, Mōri-shi?) est un clan japonais qui descend de Ōe no Hiromoto et qui établit son pouvoir dans la province d'Aki.</p>

                    <p>Après de nombreuses conquêtes, le clan Mori s'impose comme l'un des clans les plus puissants du Japon. Il possède l'une des armées 
                       les plus importantes de la bataille de Sekigahara de 1600 avec 15 000 hommes. Cependant celle-ci est engagée dans le camp des perdants. 
                       Après cette bataille, le clan perd trois des provinces qu'il gouverne et doit déplacer sa capitale de Hiroshima à Hagi. 
                       Il ne reste au clan que les provinces de Suo et la Nagato, appelée domaine de Chōshū.</p>

                    <p>Après l'abolition du système han en 1871, le clan Mōri devient une lignée de ducs.</p>

                    <div class="up"><a href="#">(Up)</a></div>
                    <div class="source"><a href="https://fr.wikipedia.org/wiki/Clan_M%C5%8Dri" target="_blank">source</a></div>
                </div> <!--fermeture div article_Faction_1300-->

                <div class="article_Faction_1400">
                    <h2 id="article_Faction_1400">Clan Oda : </h2>
                    <p>Le clan Oda (織田家) est l'un des plus puissants clans de daimyo de l'époque Sengoku (XVe siècle/XVIe siècle) de l'histoire du Japon.
                        Oda Nobunaga est le plus grand représentant de ce clan, à l'origine de l'unification du Japon.</p>

                    <h3>Origines</h3>
                    <p>Selon les dires d’Oda Nobunaga, le clan Oda tirerait ses racines du village d’Oda dans la province d’Echizen 
                       lorsqu’un moine du nom de Taira no Chikazane fuit vers ce village au moment où le clan Minamoto détruit le clan Taira.
                       C’est alors qu’il changea son nom pour Oda Chikazane et commença une nouvelle lignée de prêtres qui prirent le nom du village
                       comme nom de clan. Le clan Oda fut le vassal du clan Shiba pendant plusieurs siècles, 
                       le clan qui avaient la plus grande partie d’Echizen sous contrôle. 
                       En 1435 le clan Oda reçu le château d'Inuyama grâce à la confiance de Shiba Yoshitake. 
                       Le clan était à l’époque déjà shugo-dai depuis plusieurs générations.</p>

                    <h3>L’indépendance du clan</h3>
                    <p>À la mort de Shiba Yoshitake en 1452, plusieurs vassaux refusèrent de reconnaître le successeur de Yoshitake,
                       Shiba Yoshitoshi. D’importants clans tels que les Asakura et les Oda soutenaient Shiba Yoshikado. 
                       C’est ainsi que le clan Shiba perdit le contrôle de ses vassaux qui prirent chacun le contrôle du domaine 
                       qui leur était attribué et commencèrent à régner individuellement. La puissance du clan Shiba diminuait à mesure 
                       que la puissance des autres clans, tel que le clan Oda, augmenta. Le clan Oda gagna le contrôle de plus en plus de régions, 
                       et ce fut ainsi que la province d’Owari tomba entièrement entre les mains du clan en 1475. 
                       Cependant le clan était à cette époque divisé en deux branches rivales, 
                       les Oda Ise no Kami de Iwakura et les Oda Yamato no Kami de Kiyosu.</p>

                    <h3>Le début de l’expansion du clan</h3>
                    <p>Au début du XVIe siècle, le clan Oda était encore toujours divisé en deux branches différentes. 
                       Dans la branche la plus faible du clan, les Oda de Kiyosu, naquit en 1510 Oda Nobuhide, fils d’Oda Nobusada. 
                       Il devint chef de clan après son père.</p>

                    <p>En 1534 naquit Oda Nobunaga. Il était le deuxième fils de Nobuhide mais fut considéré comme le véritable héritier
                       du clan car son grand frère, Oda Nobuhiro, n’était pas apte à reprendre le rôle de chef de clan. 
                       Il fut donc mis en avant comme un fils illégitime. C’est comme ça que Nobunaga finira par devenir chef de clan.</p>

                    <p>Dans les années 1540 Oda Nobuhide retint Yamato no Kami Michikatsu et devint ainsi Daiymō de l’ère Sengoku
                       avec des ambitions régionales. Oda Nobunaga partit en guerre pour la première fois en 1541, sous le commandement de son père. 
                       Ceci contre le clan Matsudaira de la province de Mikawa. À la suite de ce conflit, le château d’Anjō tomba entre les mains de Nobuhide.
                       Oda Nobuhide mourut de maladie en 1551 dans le château de Suemori dans la province d’Owari. 
                       Après sa mort quelques doutes sur l’héritier légitime font surface. 
                       Mais vu qu’Oda Nobuhiro fut considéré comme un enfant illégitime, Oda Nobunaga saisit sa chance et fut reconnu en 1553
                       comme successeur légitime d’Oda Nobuhide. Il devint ainsi chef de clan et daimyō.</p>

                    <h3>Sous le règne de Nobunaga</h3>
                    <p>Provinces conquises par le clan Oda et Oda Nobunaga</p>

                    <p>Dès que Nobunaga pris le pouvoir, il défia la branche Iwakura du clan Oda pour prendre le contrôle sur la province d’Owari.
                       C’est à ce moment que Nobunaga commença à devenir déraisonnable et inconvenant. Ceci fut la cause du suicide de Hirate Masahide,
                       un serviteur du clan. Un temple fut construit plus tard en son honneur par Nobunaga, sous le nom de Seishu-ji ou Masahide-ji. 
                       Un an après que Nobunaga ait pris le contrôle du clan Shiba Yoshimune, le Shugo d’Owari fut assassiné 
                       dans le château de Kiyosu par Oda Nobutomo. Nobutomo faisait partie de la branche Iwakura mais fit ceci pour soutenir Nobunaga. 
                       C’est ainsi qu’il donna le château qu’il conquit à Nobunaga.</p>

                    <p>En 1556 Oda Nobuyuki, un des plus jeunes frères de Nobunaga, essaya de reprendre le contrôle sur sa famille et son clan,
                       avec l’aide de Shibata Katsuie et Hayashi Hidesada. Il fut néanmoins battu par les partisans de Nobunaga. 
                       Il fut gracié pour ses actes de rébellion envers son frère. En 1557 Nobunaga pris possession du château d’Iwakura et sécurisa 
                       ainsi en grande partie la province d’Owari. Mais il fut à nouveau défié par un membre de sa famille. 
                       C’est comme ça qu’Oda Nobuhiro s’allia avec Saito Yoshitatsu de la province de Mino. 
                       Yoshitatsu était à l’époque déjà poursuivi par Nobunaga depuis un an pour le meurtre de Saito Dosan, 
                       le père de Yoshitatsu. Nobunaga découvrit encore une fois les fomentations à son égard mais gracia encore une fois son frère. 
                       Entre temps Nobuyuki recommença un autre complot contre son frère mais celle-ci ne réussit pas et il fut cette fois tué pour son crime. 
                       Cette même année naquit le premier enfant de Nobunaga, à savoir Oda Nobutada.</p>

                    <p>Imagawa Yoshimoto partit en campagne contre Kyoto. C’est comme ça qu’il s’introduira dans la province d’Owari 
                       et prendra le contrôle des forts de Marume et Washizu avec l’aide des Matsudaira. 
                       Nobunaga quitta immédiatement Kiyosu pour les contrer. Malgré une grande supériorité numérique pour les ennemis de Nobunaga, 
                       celui-ci remporta la bataille. Après celle-ci, il entama une alliance secrète avec Matsudaira Motoyasu de la province de Mikawa. 
                       Un an plus tard Saito Yoshitatsu mourut, ce qui offrit la chance à Nobunaga de prendre le contrôle sur la province de Mino, 
                       ceci en essayant d’anéantir le clan Saito pendant les années suivantes.</p>

                    <p>Le clan Saito fut démantelé d’ici 1568 et la province de Mino tomba entre les mains de Nobunaga. 
                       Il s’établira à Inabayama, qu’il renomma Gifu. Son intérêt envers la province d’Ise grandi et fit marier son fils, 
                       Oda Nobutaka, avec Kanbe Tomomori de l’ouest d’Ise. Nobutaka prendra ainsi la place dirigeante de la famille Kanbe. 
                       Nobunaga partit en campagne contre le clan KitaBatake pour agrandir son contrôle sur Ise. 
                       Il mit fin à ce conflit avec la bataille du château d’Anotsu.</p>

                    <p>À partir de 1570 commencèrent tout un tas d’incursions contre Nobunaga car il défia l’autorité du shōgun,
                       Ashikaga Yoshiaki. C’est ainsi que des conflits contre les clans Asukara et Asai commencèrent. 
                       Ces deux clans s’allièrent par ailleurs contre le clan Oda. Après deux ans ce conflit n’était toujours pas fini 
                       et le clan Oda perdit certaines parties des provinces d’Ise et d’Omi. 
                       Pourtant cela ne l’empêcha pas d’envoyer Tokugawa Ieyasu en campagne contre le clan Takeda. 
                       À cause de quoi le clan Takeda prit le contrôle du château d’Iwamaru dans la province de Mino 
                       et fit prisonnier le cinquième fils de Nobunaga.</p>

                    <p>Le clan Oda mit fin au shogunat des Ashikaga en 1573 et neutralisa rapidement après ceci les clans Asai et Asakura. 
                       Néanmoins tous les ennemis du clan Oda ne furent pas encore neutralisés. 
                       Le clan Takeda et les Nagashima-Ikko continuèrent d’attaquer les Oda. 
                       Ce qui résultera en 1574 en un massacre de 20 000 hommes, femmes et enfants à Nagashima causé par le clan Oda.</p>

                    <p>Le clan Takeda pénétra le domaine des Tokugawa en mai 1575 et organisa un siège sur le château de Nagashino.
                       Le clan Oda dirigé par Nobunaga alla aider le clan Tokugawa ce qui créa une armée commune de 35 000 hommes 
                       contre 13 000 soldat pour le clan Takeda sur le champ de bataille. 
                       Ceci résulta en une victoire écrasante pour l’alliance Oda-Tokugawa. 
                       Au même moment les Ikko de la province d’Echizen dérangèrent le clan Oda mais ces révoltes furent endiguées 
                       d’ici la fin de cette même année.</p>

                    <p>Le clan Oda partit en guerre en 1577 contre le clan Hatano de Tamba et le clan Ishikki de Tajima,
                       car ils avaient tous deux soutenu Ashikaga Yoshiaki contre le clan Oda à l’époque du shogunat Ashikaga. 
                       Pendant ce temps Bessho Nagaharu s’allia avec les Oda et Hashiba Hideyoshi les aida à traverser la région de Chūgoku. 
                       A Hokuriku un ancien allié des Oda, Uesugi Kenshin d’Echigo, se rebella contre Nobunaga. 
                       Ceci parce que Kenshin trouva que les Oda violèrent sa sphère d’influence. Il battit les Oda près de la Tendorigawa à Kaga. 
                       Ses actions inspirèrent les rebelles dirigés par Matsunaga Hisahide à partir en guerre contre le clan Oda dans les provinces de Yamato. 
                       Le château de Hisahide fut néanmoins attaqué par Oda Nobutada et Tsutsui Junkei, ce qui le poussa à se suicider.</p>

                    <p>Le château d'Azuchi de la province d’Omi devint la capitale du clan Oda en 1578. 
                       Le clan Mori fut battu cette même année après la deuxième bataille de Kizugawaguchi. 
                       Uesugi Kenshin, Araki Murashige, seigneur du château d’Itami à Settsu et le clan Bessho se retournèrent tous contre le clan Oda. 
                       Le clan Bessho fut attaqué par Hideyoshi sous les ordres d’Oda Nobutada. 
                       Kenshin mourut avant d’avoir conquis la province de Kaga ce qui résulta en une guerre civile entre les membres du clan. 
                       Le clan Uesugi ne fut donc plus un problème pour les Oda.</p>

                    <p>Araki Murashige délaissa le château d’Itami en 1579 à la suite de la perte de deux puissants alliés pour le clan Oda 
                       et fuit vers l’ouest pour vivre dans l’ombre pour le reste de sa vie. 
                       Oda Nobuo entreprit de sa propre initiative de pénétrer dans la province d’Iga ce qui fera qu’il sera réprimandé par son père Nobunaga.
                       Tokugawa Nobuyasu, fils de Tokugawa Ieyasu, fut également suspecté de trahison envers le clan Oda. 
                       Nobunaga l’obligera à se suicider.</p>

                    <p>Nobunaga rejeta certains de ses alliés d’ici 1581, tels que Sakuma Nobumori, Inaba Ittetsu et Hayashi Hidesada.
                       Hideyoshi prit en même temps le contrôle sur le château de Miki et fit du clan Ukita de la province de Bizen un allié du clan Oda
                       au désavantage du clan Mori. Le pouvoir des Kaga Ikko fut également rompu. 
                       Le clan Oda put par la suite mettre plus de pression sur la province d’Etchū et Noto, 
                       au moment où celle-ci était sous le contrôle du clan Uesugi. 
                       Les Oda réussirent à prendre Noto mais la plus grande partie de la province d’Etchū resta aux mains du clan Uesugi. 
                       Nobunaga attaqua néanmoins la province d’Iga et y défit toute résistance.</p>

                    <p>Le clan Oda prit le château d’Ūzu dans la province d’Etchū en 1582. 
                        Ceci fut une cuisante défaite pour les Uesugi et ouvrit le chemin vers la province Echigo pour une invasion par le clan Oda. 
                        Nobunaga coordonna une invasion sur le domaine des Takeda en mai avec l’aide des Tokugawa et des Hōjō. 
                        La plus grandes partie des survivants du clan Takeda furent exécutés sur les ordres de Nobunaga. Dès son retour à Kyoto, 
                        Nobunaga commença à organiser une invasion sur le domaine de Chosokabe sur Shikoku. 
                        Le 20 juin de cette année Oda Nobunaga fut trahi par Akechi Mitsuhide, maintenant connu sous le nom de l’incident du Honnō-ji. 
                        Avec Oda Nobunaga mourut également son fils Oda Katsunaga pendant qu’Oda Nobutada fut encerclé au château de Nijō et se suicida. 
                        Le clan Hōjō saisit l’opportunité pour chasser le clan Oda de Kozuke alors que l’armée des Oda suspendit son avancée 
                        dans la province d’Etchū. Une rébellion apparut dans la province de Kai et le gouverneur du clan Oda, Kawajiri Hidekane, 
                        fut tué pendant sa fuite. C’est ainsi que commença la chute du pouvoir du clan Oda.</p>

                    <h3>Après la mort de Nobunaga</h3>
                    <p>Après la mort d’Oda Nobunaga et de son premier fils Nobutada, seigneur de Gifu, 
                       lors de l’incident du Honnō-ji (1582) Nobutaka, son deuxième fils, pris le contrôle sur la région de Gifu. 
                       Il fit cela avec l’aide de Shibata Katsuie pour éviter que Toyotomi Hideyoshi prenne le pouvoir. 
                       Shibata Katsuie fut finalement battu pendant la bataille de Shizugatake, ce qui fit perdre son plus puissant allié à Nobutaka. 
                       Il fut par la suite battu par son frère, Oda Nobokatsu, et Toyotomi Hideyoshi en 1583. 
                       Nobukatsu ne resta néanmoins pas plus longtemps l’allié de Hideyoshi et s’allia avec le futur Shōgun, Tokugawa Ieyasu. 
                       Il partit en guerre contre Hideyoshi avec Ieyasu dans la campagne de Komaki-Nagakute de 1584. 
                       Après une bataille n’étant pas réellement décisive il devint daimyō de Kiyosu (une grande partie de la province d’Owari et des parties d’Ise).</p>

                    <p>Il est dit que Nobutaka est le troisième fils de Nobunaga et Nobukatsu le deuxième, mais c’est en vérité l’inverse. 
                       Ils sont nés à trois semaines d’intervalle en 1558 mais Nobutaka était le fils d’une concubine de Nobunaga de classe inférieure. 
                       C’est pour cela que Nobukatsu reçut priorité dans la généalogie. Il réussit également à recevoir une place très haut placée auprès de la cour impériale. 
                       Il devint ministre de l’intérieur (Naidaijin 内大臣) en 1587. Il fut par contre exproprié de toutes ses terres par Hideyoshi 
                       car il refusa de partir en campagne pour lui. Cette campagne avait pour but de faire des fiefs de toutes les terres abandonnées par Ieyasu. 
                       Ceci deviendra la campagne d’Odawara de 1590.</p>

                    <p>Le fils de Nobutada, Oda Hidenobu (1580-1605), devint seigneur d’Azuchi en 1582 et héritier de Nobunaga. 
                       Ceci fut décidé lors de la conférence de Kiyosu. Hidenobu devint en 1590 daimyō d’un domaine de 135 000 koku. 
                       Il fut baptisé comme chrétien en 1595 et devint fervent défenseur du catholicisme à cause de quoi tout son domaine dut devenir catholique. 
                       Durant le grand conflit de 1600 il se tourna contre Tokugawa Ieyasu. Ce qui le fit perdre son château à Gifu 
                       à la suite de l’attaque coordonnée par Fukushima Masanori, un allié d’Ieyasu. Ceci se passa trois semaines avant la bataille de Sekigahara. 
                       Hidenobu se fit exproprier de ses terres et c’est ainsi que tomba la branche principale du clan Oda.</p>

                    <p>Le plus jeune frère de Nobunage, Nagamasu aussi connu comme le grand maître du thé Oda Uraku, 
                       se battit pour Tokugawa Ieyasu lors de la bataille de Sekigahara. Ieyasu donna suite à la victoire un domaine de 30 000 koku 
                       dans la région de Settsu et de Yamato. Ses descendants furent daimyō de Yamato jusqu’à la fin de l’ère Edo. 
                       Nobukatsu reçu en 1615 un domaine de 50 000 koku à Matsuyama dans la région de Yamato. 
                       Ce domaine fut réduit de 20 000 koku deux ans plus tard, ils allèrent à Nobuyoshi, fils de Nobukatsu, à Obata dans la province de Kōzuke. 
                       Le domaine de Matsuyama fut échangé pour des fiefs par les descendants de Nobukatsu en 1695. 
                       C’est ainsi qu’ils reçurent un domaine de 20 000 koku à Kaibara dans la province de Tamba. Ce domaine était le domaine du frère de Nobunaga, 
                       Oda Nobukane (1543-1614) entre 1598 et 1650. Ce domaine fut en possession du clan Oda jusqu’à la fin de la restauration Meiji (1868). 
                       Une autre partie du clan Oda, les Oda de Obata fut déplacée vers la province de Dewa. Et par la suite encore déplacée deux fois. 
                       La première fois en 1767 vers Takahata et vers Tendō en 1830 où ils eurent un domaine de 20 000 koku. 
                       Ceci jusqu’à l’abolition des domaines féodaux, aussi appelé système han en 1871.</p>

                    <div class="up"><a href="#">(Up)</a></div>
                    <div class="source"><a href="https://fr.wikipedia.org/wiki/Clan_Oda" target="_blank">source</a></div>
                </div> <!--fermeture div article_Faction_1400-->

                <div class="article_Faction_1500">
                    <h2 id="article_Faction_1500">Clan Shimazu : </h2>
                    <h3>Les origines des Shimazu</h3>
                    <p>Cette famille descend de l'empereur Seiwa (850-880) et du shogun Minamoto no Yoritomo (1147-1199), 
                        par son fils Tadahisa qui prendra le nom du domaine de Shimazu (province de Hyuga).</p>

                    <p>Il n'est pas exagéré de prétendre que la famille Shimazu fut l'une des plus puissantes machines de guerre de la [[période Sengoku]].
                        L'extrême sud du Kyūshū se divisait alors en deux provinces : province de Satsuma et province d'Osumi. 
                        Depuis la période Kamakura, les Shimazu étaient nommés 'shugo' (gouverneur de province désigné par le régime,
                        chargé de la police et de l'armée).</p>

                    <h3>Les Shimazu contre Toyotomi Hideyoshi</h3>
                    <p>Le clan Shimazu, le plus puissant de Kyūshū, décida d'unifier son île. Pour cela il devait soumettre deux clans :
                       celui des Otomo et celui des Ryūzōji. Mais la bataille, remportée par les Shimazu contre le clan Ryūzōji 
                       et conduite par Ryuzoji Takanobu, attira l'attention de Toyotomi Hideyoshi sur la puissance émergente du clan Shimazu. 
                       Trois ans plus tard, prétextant apporter de l'aide au clan Otomo, Hideyoshi envahit Kyūshū avec ses troupes 
                       et combattit le clan Shimazu à la bataille d'Okita Nawate le 5 mars 1584.</p>

                    <p>En 1587, Toyotomi Hideyoshi attaqua la forteresse de Takajo ; Yamada Arinobu commandait 1 500 hommes. Cette fois,
                       il fut assiégé par 80 000 soldats menés par Hashiba Hidenaga, vassal du grand conquérant. 
                       Le 10 avril, Shimazu Yoshihiro fit un raid nocturne sur la forteresse de Shiranezaka. Mais, 
                       comme ils s'attendaient à être attaqués, les soldats avaient posé des pièges un peu partout pour protéger les abords des lieux.
                       Yoshihiro ne put prendre le château durant la nuit. Lorsque les renforts de Hidenaga arrivèrent, 
                       Yoshihiro et Yoshihisa durent battre en retraite à l'aube. 
                       Les opérations les mieux coordonnées des Shimazu ne pouvaient venir à bout des troupes bien entraînées de Toyotomi Hideyoshi.</p>

                    <h3>Les Shimazu en Corée</h3>
                    <p>La bataille navale de No Ryang est la dernière bataille de la guerre Imjin, 
                       qui a opposé la Corée de la dynastie Choson et la Chine de la dynastie Ming à l'empire Japonais de Hideyoshi Toyotomi, 
                       de 1592 à 1598. La flotte sino-coréenne était menée par l'amiral Yi sun-sin et par le Chinois Chen Lin, tandis que du côté japonais,
                       Shimazu Yoshihiro était le commandant de la flotte. Le 16 décembre 1598, à No Ryang, sur les côtes coréennes, 
                       se sont affrontés l'amiral Yi Sun-sin et Shimazu Yoshihiro. Cette bataille marqua la toute première utilisation du kobuk-son
                       ou keobukseon (« bateau tortue »), premier navire blindé à livrer bataille en haute mer ; 
                       c'est l'amiral Yi lui-même qui avait conçu les plans de ce navire. Mais les Coréens et les Chinois avaient aussi 
                       comme navires 6 jonques de guerre, 82 panokseon et 15 600 hommes. 
                       Les Japonais quant à eux avaient 500 navires et 20 000 hommes.
                       Dans la bataille, la flotte sino-coréenne bien qu'en infériorité numérique, avait une puissance de feu supérieure 
                       et des structures plus solides que l'armée japonaise.</p>

                    <p>Dans la première phase de la bataille, l'attaque des canons chinois et coréens empêchèrent les navires des Shimazu de bouger,
                        mais l'étroitesse du détroit limitait également la manœuvrabilité. 
                        Puis Chen Lin ordonna à sa flotte d'engager la mêlée avec les Japonais ; 
                        cependant, cela permit aux arquebusiers japonais d'utiliser leur tactiques traditionnelles d'abordage. 
                        Vers le milieu de la bataille, la moitié des navires de Shimazu furent coulés ou capturés par l'ennemi.
                        Le bruit courut que le vaisseau amiral de Shimazu Yoshihiro avait été coulé et que Shimazu lui-même était cramponné 
                        à un bout de bois tandis que, au moyen de grappins, des soldats chinois tentaient de le monter à bord.</p>

                    <p>Voyant qu'ils ne gagneraient pas, les navires japonais commencèrent à battre en retraite. 
                       Dans la dernière phase de la bataille, l'amiral Yi Sun-sin ordonna la poursuite mais il reçut un tir d'arquebuse
                       au niveau de l'aisselle gauche. Le combat continua, cependant les Japonais battaient en retraite. 
                       Sur les 500 navires nippons, on estime que seulement 150 à 200 regagnèrent le Japon. Tous les grands généraux qui étaient en Corée,
                       comme Konishi, Shimazu et Kiyomasana Kato, se réunirent à Pusan, puis se retirèrent vers le Japon, le 21 décembre 1598.</p>

                    <h3>La bataille de Sekigahara</h3>
                    <p>La capitale de la famille était la ville de Kagoshima. En 1600, la famille participa, 
                       dans le camp des perdants à la bataille de Sekigahara. Shimazu Yoshihiro (1535-1619), 
                       dix-septième chef de la lignée Shimazu, réputé bon guerrier (surnommé le « démon Shimazu » pour avoir impressionné 
                       ses ennemis à Sekigahara) et Toyohisa Shimazu participèrent à la bataille.</p>

                    <h3>La fin des samouraïs</h3>
                    <p>À la fin de l'époque d'Edo arrive une flotte de vaisseaux noirs, avec à son bord le commodore américain, Matthew Calbraith Perry.
                       Le shogunat n'ayant plus ni le temps ni les moyens de surveiller tous les fiefs du Japon,
                       ceux-ci finirent par le dévorer sous le règne de Yoshinobu Tokugawa (1866-1867). 
                       Mais deux des trois héros de l'ère Meiji sont de Satsuma (province sous le contrôle des Shimazu) : 
                       Saigō Takamori, Okubo Toshimichi. Le dernier provient de Choshu, il s'agit de Takayoshi Kido.</p>

                    <p>En 1877, le clan se révolta pour tenter de faire perdurer la société des samouraïs,
                       qui venait d'être abolie suite aux réformes de l'ère Meiji. La révolte fut réprimée difficilement par les troupes impériales,
                       déjà fort occupées à régler des troubles avec les forces shogunales. 
                       Près de 40 000 hommes partirent pour mater la Rébellion de Satsuma menée par les troupes de Saigo, 
                       mais Tokyo mobilisa 70 000 hommes de l'armée de terre ainsi que des forces navales. Saigō Takamori, 
                       blessé au combat le 24 septembre 1877, décida de se faire seppuku. 
                       Il est aujourd'hui reconnu par le peuple comme « le dernier samouraï ». 
                       Le clan Shimazu fait partie des rares familles japonaises à avoir conservé le même fief (de 700 000 koku) de la période Kamakura 
                       à la restauration de Meiji.</p>

                       <div class="up"><a href="#">(Up)</a></div>
                    <div class="source"><a href="https://fr.wikipedia.org/wiki/Clan_Shimazu" target="_blank">source</a></div>
                </div> <!--fermeture div article_Faction_1500-->

                <div class="article_Faction_1600">
                    <h2 id="article_Faction_1600">Clan Takeda : </h2>
                    <p>Le clan Takeda (武田氏, Takeda-shi?) était l'une des plus puissantes familles de daimyos.</p>

                    <p>La puissance de cette famille est en réalité beaucoup plus ancienne. Cette famille est une branche des princes Minamoto,
                       descendant directement de l'Empereur Seiwa (850-880) et du prince Minamoto no Yoriyoshi (998-1082). 
                       Minamoto no Yoshikiyo (1163 ap. J.-C.) sera le premier à utiliser le nom de Takeda, du shōen (« grand domaine ») de Takeda, 
                       dans la province de Kai.</p>

                    <p>Au XIIe siècle, à la fin de la période Heian, la famille Takeda contrôle la province de Kai,
                       et ceux que l'on nomme dans les récits de l'époque les "Kai Genji" (c'est-à-dire les « Minamoto de la province de Kai »),
                       sont les Takeda. En 1180, lors de la guerre de Gempei, le ralliement des Takeda et des Nitta à la cause de 
                       leur cousin Minamoto no Yoritomo sera un tournant décisif, ces familles apportant leur propre armée de 20 000 soldats chacune.</p>

                    <p>Nobumitsu Takeda (1162-1248) recevra la province d'Aki après la guerre de Shokyu (1221). 
                       Du XIIIe au XVIe siècle, les Takeda contrôlent 3 provinces (Kai pour la branche aînée, Wakasa et Aki pour la seconde branche), 
                       avec le titre prestigieux de shugo.</p>

                    <p>En 1415, ils aident à réprimer la rébellion de Uesugi Zenshū. Ashikaga Mochiuji, 
                       le seigneur d'Uesugi et l'homme contre qui la rébellion était organisée, lança des représailles contre les Takeda, 
                       ce qui amorça la longue rivalité entre le clan Uesugi et celui de Takeda, qui durera environ 150 ans.</p>

                    <p>Harunobu Takeda, qui prendra plus tard le nom de Shingen, succède à son père Nobutora en 1540, 
                       devenant seigneur de Kai et commençant rapidement une politique d'expansion. 
                       Même s'il affronte le clan Hōjō un certain nombre de fois, la plupart de son expansion se fait en direction du nord, 
                       où il mène ses plus célèbre batailles, contre Kenshin Uesugi.</p>

                    <p>Shingen est célèbre pour son génie tactique et ses innovations, même si certains historiens ont affirmé que ses tactiques 
                       n'étaient ni particulièrement impressionnantes, ni révolutionnaires. 
                       Quoi qu'il en soit, Shingen est surtout célèbre pour son utilisation de la charge de cavalerie. 
                       Jusqu'au milieu du XVIe siècle et l'arrivée au pouvoir de Shingen, les samouraïs montés étaient surtout des archers. 
                       Il y avait déjà à l'époque une tendance à plus utiliser des grandes armées basées sur l'infanterie, 
                       comprenant un grand nombre d'archers à pied. Dans le but de se débarrasser de ces troupes à longue portée, 
                       Shingen transforme ses samouraïs montés d'archers en lanciers, 
                       et utilise la charge de cavalerie avec des effets dévastateurs à la bataille de Mikata ga Hara en 1572. 
                       La puissance de la nouvelle tactique de Shingen devient rapidement si célèbre que l'armée Takeda est bientôt 
                       connue sous le nom de kiba gundan (騎馬軍団?, l'« armée montée »). 
                       Certains les appellent même les shinshutsu kibotsu (神出鬼没?), ou « diables sacrés ».</p>

                    <p>Shingen meurt en 1573 à l'âge de 53 ans, probablement d'une blessure par balle. 
                       Son fils Katsuyori, moins bon stratège, lui succède, mais est vaincu par Nobunaga Oda à la bataille de Tenmokuzan en 1582.</p>

                    <p>Le kōshū hatto composé au cours du XVe siècle est le code de loi du clan Takeda, et le Kōyō gunkan, 
                       principalement compilé par Masanobu Kōsaka au milieu du XVIe siècle, 
                       est une chronique de l'histoire du clan et un traité sur les innovations de Shingen en matière de tactique.</p>

                    <div class="up"><a href="#">(Up)</a></div>
                    <div class="source"><a href="https://fr.wikipedia.org/wiki/Clan_Takeda" target="_blank">source</a></div>
                </div> <!--fermeture div article_Faction_1600-->

                <div class="article_Faction_1700">
                    <h2 id="article_Faction_1700">Clan Uesugi : </h2>
                    <p>Le clan Uesugi (上杉氏, -shi) est une ancienne famille de daimyo du Japon connue pour son influence 
                        pendant la période Muromachi et la période Sengoku.</p>

                    <p>Cette famille descend des Fujiwara.</p>

                    <p>Fujiwara no Shigefusa, descendant de Fujiwara no Yoshikado (IXe siècle) reçoit le domaine d'Uesugi (province de Tango) 
                       au XIIIe siècle et prend le nom du lieu. Il est l'arrière-arrière-grand-père du shogun Ashikaga Takauji.</p>

                    <p>La famille est divisée en trois branches : Ōgigayatsu, Inukake et Yamanouchi Uesugi.</p>

                    <p>Le clan est principalement connu grâce à Kenshin Uesugi l'un des daimyo les plus puissants de son époque.<p>

                    <div class="source"><a href="https://fr.wikipedia.org/wiki/Clan_Uesugi" target="_blank">source</a></div>  
                </div> <!--fermeture div article_Faction_1700-->
                <hr>

                    <div class='pageup'>
                        <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                    </div>
            </main>

            <footer>
                test footer                
            </footer>

        </div> <!-- fin wrap -->        
    </body>
</html>