<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
include 'Creation_PersonnageClass.php';
session_start();
/*session is started if you don't write this line can't use $_Session  global variable*/
if (isset($_POST['textarea_connexion_pseudo']))
{
    $_SESSION["Pseudo"];
}
?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Creation_Personnage</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>                
                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_creation_personnage">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>
            
            <aside>
                <form action="Recherche.php" method="post">
                    <div class="recherche">RECHERCHE :<br>
                        <div class="rech_radio">
                            <input type="radio" name="choix" value="Bouton_Radio_Faction" checked> Faction<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Territoire"> Territoire<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Declin"> Année de déclin
                        </div> <!--fermeture div rech_radio-->
                            <input type="textarea" name="textarea_recherche1"><br>
                        <button type="submit" name="valider1" value="Submit">Valider</button>
                    </div> <!--fermeture div recherche-->
                </form>               
            </aside>

            <main>
                <h1>Création de Personnage : </h1>

                <div class="article_Creation_personnage_10000">
                    <form action="Creation_Personnage.php" method="post">
                        <p>Nom du Personnage (*) :</p>
                        <input type="textarea" name="textarea_Creation_Personnage_Nom"><br>
                        <p>Prenom du Personnage (*) :</p>
                        <input type="textarea" name="textarea_Creation_Personnage_Prenom"><br>
                        <p>Sexe du Personnage (*) :</p>
                        <input type="radio" name="sexe_personnage" value="Masculin" checked> Masculin<br>
                        <input type="radio" name="sexe_personnage" value="Feminin"> Féminin<br>
                        <p>Age du Personnage (**) :</p>
                        <input type="textarea" name="textarea_Creation_Personnage_Age"><br>  
                        <p>Faction du Personnage (*) :</p>
                        <input type="textarea" name="textarea_Creation_Personnage_Faction"><br> 
                        <p>Image du Personnage :</p>
                        <input type="textarea" name="textarea_Creation_Personnage_Image"><br><br>
                        <button type="submit" name="bouton_valider_inscription" value="Submit">Valider</button>
                    </form>
                    <p>(*) : Champ obligatoire !</p>
                    <p>(**) : Veuillez entrer un âge compris entre 4 et 110 ans ou bien celui-ci sera mis à zéro !</p>
                </div> <!--fermeture div article_Creation_personnage_10000-->
                <?php
                        try
                        {                  
                            if(isset($_POST["textarea_Creation_Personnage_Nom"]) && ($_POST["textarea_Creation_Personnage_Prenom"])
                            && ($_POST["textarea_Creation_Personnage_Faction"])) 
                            {
                                $creationPersonnage = new ManagerClass($base);
                                $creation = new Creation_PersonnageClass();
                                $creation->setNomPersonnage(htmlentities(addslashes($_POST["textarea_Creation_Personnage_Nom"]), ENT_QUOTES));
                                $creation->setPrenomPersonnage(htmlentities(addslashes($_POST["textarea_Creation_Personnage_Prenom"]), ENT_QUOTES));
                                $creation->setSexePersonnage($_POST["sexe_personnage"]);
                                $creation->setAgePersonnage(htmlentities(addslashes($_POST["textarea_Creation_Personnage_Age"]), ENT_QUOTES));
                                $creation->setImagePersonnage(htmlentities(addslashes($_POST["textarea_Creation_Personnage_Image"]), ENT_QUOTES));
                                $creation->setPseudoPersonnage($_SESSION['Pseudo']);
                                $creation->setFactionPersonnage(htmlentities(addslashes($_POST["textarea_Creation_Personnage_Faction"]), ENT_QUOTES));
                                $creationPersonnage->CreationPersonnage($base, $creation);
                            } else {
                                echo '<br/>Veuillez au moins remplir tous les champs obligatoire.<br/>';
                            }                            
                        } 
                        catch (Exception $ex) 
                        {
                            echo '<br/>Erreur dans les fonctions recherches.';
                            die('Erreur : '.$ex->getMessage());
                        }                        
                    ?> 
                <hr>

                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </main>

            <footer>
                test footer                
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>