<?php
require 'Manager/ConnexionBDD.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $_SESSION["Pseudo"];
}

?>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Histoire</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>
                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_histoire">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <aside>
                <form action="Recherche.php" method="post">
                    <div class="recherche">RECHERCHE :<br>
                        <div class="rech_radio">
                            <input type="radio" name="choix" value="Bouton_Radio_Faction" checked> Faction<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Territoire"> Territoire<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Declin"> Année de déclin
                        </div> <!--fermeture div rech_radio-->
                        <input type="textarea" name="textarea_recherche1"></input><br>
                        <button type="submit" name="valider1" value="Submit">Valider</button>
                    </div> <!--fermeture div recherche-->
                </form>

                <ul>
                    <li><strong><a href="#article_Histoire_3000">Epoque Sengoku</a></strong></li>
                    <li><strong><a href="#article_Histoire_3100">Les causes</a></strong></li>
                    <li><strong><a href="#article_Histoire_3200">Gekokujō</a></strong></li>
                    <li><strong><a href="#article_Histoire_3300">Les ligues</a></strong></li>
                    <li><strong><a href="#article_Histoire_3400">Principautés et villes</a></strong></li>
                    <li><strong><a href="#article_Histoire_3500">Kyōto</a></strong></li>
                    <li><strong><a href="#article_Histoire_3600">La réunification</a></strong></li>
                    <li><strong><a href="#article_Histoire_3700">Déclin des clans</a></strong></li>
                </ul>                
            </aside>

            <main>
                <h1>Période Historique</h1>
                    <h2>Généralités</h2>
                        <div class="article_Histoire_3000">
                            <h3 id="article_Histoire_3000">Époque Sengoku : </h3>
                                <p>L'époque Sengoku (戦国時代, sengoku-jidai?, littéralement époque/ère des provinces en guerre, en référence à celui des Royaumes combattants chinois)
                                   est une époque de turbulences sociales, d'intrigues politiques, et de conflits militaires quasi constants qui s'étend du 
                                   milieu du XVe siècle à la fin du XVIe siècle au Japon.</p>
                                <div class="up"><a href="#">(Up)</a></div>
                        </div> <!--fermeture div article_Histoire_3000-->

                        <div class="article_Histoire_3100">
                            <h3 id="article_Histoire_3100">Les causes : </h3>
                                <p>Bien que le shogunat d'Ashikaga ait maintenu la structure du bakufu de Kamakura et ait institué un gouvernement guerrier basé 
                                   sur les mêmes droits économiques et sociaux et les engagements établis par les Hōjō avec le Goseibai Shikimoku en 1232, 
                                   il n'a pas réussi à gagner la confiance de nombreux daimyos, particulièrement ceux dont les domaines étaient loin de Kyōto.</p>

                                <p>Alors que le commerce avec la Chine augmente, l'utilisation de l'argent se développe quand apparaissent des marchés 
                                   et des villes commerciales. Ceci, combiné avec le développement de l'agriculture et de l'artisanat, 
                                   génère l'envie d'une plus grande autonomie locale à tous les niveaux de la hiérarchie sociale.</p>

                                <p>Dès le début du XVe siècle, la douleur et la misère provoquées par les catastrophes naturelles telles que les tremblements de terre 
                                    et la famine servent souvent à déclencher des soulèvements armés de fermiers las d'être trop endettés et de payer trop d'impôts.</p>
                                <div class="up"><a href="#">(Up)</a></div>
                        </div> <!--fermeture div article_Histoire_3100-->

                        <div class="article_Histoire_3200">
                            <h3 id="article_Histoire_3200">Gekokujō (下克上?, « le monde à l’envers ») : </h3>
                                <p>L'époque des provinces en guerre commence avec la fin de la guerre d'Ōnin en 1477 
                                   pour finir avec la destitution du dernier shogun Ashikaga en 1573. C'est une période de chaos, 
                                   dans un climat de guerre permanent, émaillée de trahisons, de rivalités fratricides, de retournements d'alliances. 
                                   Les clans eux-mêmes se scindent et s'affrontent pour le pouvoir local. Les vassaux renversent leur daimyo. 
                                   L'institution impériale, privée de revenu, connaît une période difficile : 
                                   un empereur aurait été réduit à vendre ses calligraphies pour vivre. 
                                   La cour est redevable des dons des daimyos, leur attribuant des titres honorifiques. 
                                   Les membres de l'ancienne noblesse, qui ont perdu leurs domaines, 
                                   survivent grâce à leurs talents artistiques et littéraires. Le shogun lui aussi a perdu ses pouvoirs, 
                                   manipulé par les gouverneurs militaires des provinces (shugo), qui s'arrogent les domaines publics 
                                   comme ceux de l'aristocratie ou des institutions religieuses (shōen). Ils se font seconder par des guerriers locaux, 
                                   les kokujin (gens du pays), et se considèrent comme des seigneurs (shugo daimyō). Quelques familles de kanrei, 
                                   comme les Hosokawa, qui détiennent la charge entre 1500 et 1530, les Hatakeyama, les Shiba cumulent les fonctions de shugo, 
                                   contrôlant jusqu'à dix provinces. Mais ces shugo daimyō ne sont pas assurés de la fidélité de leur vassaux 
                                   et de nombreux intendants (shugodai) trahissent leur maîtres absents pour prendre leur place. D'autre part, 
                                   les successions se règlent dans l'affrontement armé, les fils se disputant l'héritage1.</p>

                                <p>Le Japon ne doit qu'à son insularité de ne pas être envahi par un voisin plus puissant, 
                                    profitant de l'absence totale d'autorité centrale. Les guerres civiles favorisent la mobilité sociale : 
                                    Toyotomi Hideyoshi, par exemple, est un fils de paysan qui, remarqué par Oda Nobunaga, finira par dominer le pays.</p>
                                <div class="up"><a href="#">(Up)</a></div>
                        </div> <!--fermeture div article_Histoire_3200-->

                        <div class="article_Histoire_3300">
                            <h3 id="article_Histoire_3300">Les ligues : </h3>
                                <p>Les kokujin ou ji-zamurai (地侍?), guerriers résidents des provinces se considèrent bientôt 
                                   comme les maîtres des domaines qu'ils protègent et se lient avec les paysans aisés. Avec la disparition du pouvoir shogunal, 
                                   les communautés urbaines, commerçantes et villageoises s'organisent en ligues (一揆, ikki?), soutenues par les kokujin,
                                   pour faire valoir leurs droits auprès du shogun, des daimyos ou des institutions religieuses. 
                                   Dans les environs de la capitale Kyōto, elles prennent au début de la période le nom de Tokusei ikki 
                                   (soulèvement pour réclamer un gouvernement vertueux). Les villages se regroupent, autour du sanctuaire, 
                                   en miyaza (Ujigami) qui s'administrent et se défendent elles-mêmes sur des principes égalitaires basés sur le serment. 
                                   Si la représentation et le culte sont confiés aux familles les plus anciennes, les décisions se prennent en commun.</p>

                                <p>Parmi ces ligues, les Ikkō-ikki (一向一揆?, ligue de ceux qui sont tournés dans une seule direction) 
                                   se développent autour de la personnalité de Rennyo (蓮如?, 1415-1499), 
                                   huitième supérieur de l’École véritable de la Terre pure (浄土真宗, Jōdoshin-shū?). 
                                   En 1465, son monastère principal, le Hongan-ji est détruit par les Sōhei, moines-soldats tendai du Mont Hiei. 
                                   Rennyo voyage dans les provinces, publiant des lettres pastorales (Ofumi) qui encouragent la résistance aux autorités, 
                                   et créant un réseau de villes-temples fortifiées (寺内町, jinaichō?), avant de fonder un nouveau Hongan-ji 
                                   en 1483 à Yamashina près de Kyōto puis de se retirer au château d'Ōsaka (大阪城, Ōsaka-jō?). 
                                   Les Ikkō-ikki essaiment dans les régions du Hokuriku, du Tōkai et de Kinki, qui sont en pleine expansion. 
                                   Les confréries religieuses (kō) s'y superposent aux communautés villageoises (惣, sō?), 
                                   leur apportant une caution morale face aux shugo daimyō qui leur réclament le paiement de l'impôt. 
                                   En 1488, les habitants de la province de Kaga, soutenus par les guerriers locaux, 
                                   se soulèvent et chassent le gouverneur militaire en se réclamant de l'Ikkō-shū (一向宗?, un autre nom de la secte). 
                                   Le mouvement embrase les provinces voisines à partir de Kanazawa. La région est gouvernée pendant 70 ans par la secte.</p>
                                <div class="up"><a href="#">(Up)</a></div>
                        </div> <!--fermeture div article_Histoire_3300-->

                        <div class="article_Histoire_3400">
                            <h3 id="article_Histoire_3400">Principautés et villes : </h3>
                                <p>Parallèlement à la fondation des Ligues, se multiplient les principautés indépendantes rivales, 
                                   de plus en plus hiérarchisées, créées par des seigneurs de la guerre (戦国大名, sengoku-daimyō?) 
                                   qui les administrent de manière énergique. De taille modeste mais bien organisées, 
                                   elles se situent principalement aux alentours de la capitale. Le seigneur regroupe dans sa forteresse des guerriers 
                                   qui ne sont plus attachés à la terre mais à sa personne. Il édicte des règlements qui mettent en avant la loyauté, 
                                   la piété filiale, l'étude des classiques confucéens et les arts martiaux. Il prend en charge la justice et l'économie, 
                                   créant des marchés libres (rakuichi) pour favoriser le commerce, met en valeur les mines, encourage les guildes d'artisans 
                                   et de commerçants (za). Au pied des châteaux seigneuriaux se constituent des villes-châteaux (城下町, jōkamachi?), 
                                   comme Odawara, Sunpu, Yamaguchi, Kanazawa, etc.</p>

                                <p>Il faut également noter le développement de villes marchandes, 
                                   qui profitent de circonstances économiques favorables au commerce international, 
                                   comme Hakata à Kyūshū, Hyōgo et Sakai (堺?), dans la banlieue d'Ōsaka. Cette dernière échappe à la tutelle des daimyos 
                                   et est administrée par un conseil de marchands de trente-six membres (Egōshū). Elle est un riche port commercial, 
                                   assurant le commerce officiel avec la Chine entre 1469 et 1520, mais aussi le commerce dans la mer intérieure. 
                                   Elle est aussi un centre important de production d'armes et un centre culturel. 
                                   Le grand maître de thé Sen no Rikyū est un riche marchand de Sakai.</p>
                                <div class="up"><a href="#">(Up)</a></div>
                        </div> <!--fermeture div article_Histoire_3400-->

                        <div class="article_Histoire_3500">
                            <h3 id="article_Histoire_3500">Kyōto : </h3>
                                <p>Pendant la guerre d'Ōnin, Kyōto est ravagée par les armées des clans Yamana et Hosokawa. 
                                   Puis la ville est le théâtre d'affrontements entre les sectes Hokke-shū (法華宗?) 
                                   et Jōdo shinshū dans les années 1530. La population, manipulée par le kanrei Hosokawa détruit le temple Jōdoshin-shû 
                                   et Kyōto est gouvernée pendant trois ans par ses habitants, organisés en communes (惣町, sōchō?), 
                                   avant que les moines de l'Enryaku-ji sur le Mont Hiei ne l'incendient le 13 août 1536 
                                   pour rétablir provisoirement l'autorité du shogun : C'est l'écrasement de la secte Hokke de Kyōto à l'ère Tenbun 
                                   (天文法華の乱, Tenbun hokke no ran?).</p>

                                <p>La capitale se divise en deux bourgs, Kami-gyō (上京?) et Shimo-gyō (下京?), 
                                   mais demeure avec les provinces qui entourent le centre économique et culturel du Japon, 
                                   malgré la multiplication des centres régionaux. La restauration de la fête de Gion Matsuri en 1500 
                                   indique peut-être le redressement de la ville après les troubles, notamment grâce au dynamisme des artisans 
                                   et des commerçants. Il apparaît une nouvelle classe sociale (町人, chōnin?, traduit par bourgeois) 
                                   qui s'organise en communautés (les noms de rue commencent à se fixer). 
                                   En 1533, le shogun Ashikaga fait interdire toutes les cérémonies religieuses : 
                                   les habitants du quartier obtiennent que le défilé ait lieu sans célébration. 
                                   La fête devient un défilé de chars représentant chaque communauté2. En 1501, c'est la fête de Kamo qui est restaurée. 
                                   Les monastères conservent leur puissance malgré les affrontements entre sectes. 
                                   L'époque voit la réalisation de nombreux jardins (les jardins de pierre du Ryōan-ji 
                                   et du Daisen-in au début du XVIe siècle). C'est aussi l'époque de la culture Higashiyama Bunka 
                                   (le Ginkaku-ji est achevé en 1489)</p>
                                <div class="up"><a href="#">(Up)</a></div>
                        </div> <!--fermeture div article_Histoire_3500-->

                        <div class="article_Histoire_3600">
                            <h3 id="article_Histoire_3600">La réunification : </h3>
                                <p>La période Sengoku est une période de transition, qui voit l'émergence des communautés villageoises, 
                                   qui remplacent les grands domaines féodaux, de la bourgeoisie des villes et de pouvoirs provinciaux. 
                                   Le Japon entre dans l'époque prémoderne (et non moderne, celle-ci commençant à l'époque de Meiji), 
                                   si on peut faire référence à ce qui se passe en Europe à la même époque. 
                                   Celle qui suit verra la réunification du pays sous la conduite de grands généraux, 
                                   qui devront composer avec la nouvelle donne.</p>
                                <div class="up"><a href="#">(Up)</a></div>
                        </div> <!--fermeture article_Histoire_3600-->

                        <div class="source"><a href="https://fr.wikipedia.org/wiki/%C3%89poque_Sengoku" target="_blank">source</a></div>

                        <div class="article_Histoire_3700">
                            <h2 id="article_Histoire_3700">Déclin des clans : </h2>                                                                

                                <h3>Chosokabe</h3>
                                <p>Date de déclin 1587</p>

                                <h3>Date</h3>
                                <p>Date de déclin 1590</p>

                                <h3>Hojo</h3>
                                <p>Date de déclin 1590</p>

                                <h3>Mori</h3>
                                <p>Date de déclin 1579</p>

                                <h3>Oda</h3>
                                <p>Date de déclin 1582</p>

                                <h3>Shimazu</h3>
                                <p>Date de déclin 1584</p>

                                <h3>Takeda</h3>    
                                <p>Date de déclin 1573</p>

                                <h3>Uesugi</h3>
                                <p>Date de déclin 1578</p>
                        </div> <!--fermeture article_Histoire_3700-->

                        <div class='pageup'>
                            <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                        </div>
            </main>

            <footer>
                test footer
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>