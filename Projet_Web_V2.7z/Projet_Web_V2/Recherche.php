<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $_SESSION["Pseudo"];
}
?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Accueil</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>

                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_recherche">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <div class="main2">
                <h1>Recherche : </h1>
                <div class="recherche">RECHERCHE :<br>
                    <form action="Recherche.php" method="post">
                        <input type="radio" name="choix" value="Bouton_Radio_Faction" checked> Faction<br>
                        <input type="radio" name="choix" value="Bouton_Radio_Territoire"> Territoire<br>
                        <input type="radio" name="choix" value="Bouton_Radio_Declin"> Année de déclin<br>
                        <input type="textarea" name="textarea_recherche1"><br><br>
                        <button type="submit" name="valider1" value="Submit">Valider</button>
                        <p>RECHERCHE AVANCEE :<p><br>
                        <input type="textarea" name="textarea_recherche_avancee"></br>
                        <button type="submit" name="valider_recherche_avancee" value="Submit">Valider</button>
                    </form>
                </div> <!--fermeture div recherche-->

                <div class="article_Recherche_5000">                    
                    <?php
                        try
                        {                      
                            if(isset($_POST['textarea_recherche1'])) 
                            {
                                $recherche = new ManagerClass($base);                                         
                                $recherche->Recherche($base);
                            } else {
                                echo '<br/>Veuillez remplir le champ de recherche<br/>';
                            }
                            if(isset($_POST['textarea_recherche_avancee'])) 
                            {
                                $rechercheAvancee = new ManagerClass($base);                                         
                                $rechercheAvancee->RechercheAvancee($base);
                            } else {
                                echo '<br/>Veuillez remplir le champ de recherche avancée<br/>';
                            }
                        } 
                        catch (Exception $ex) 
                        {
                            echo '<br/>Erreur dans les fonctions recherches.';
                            die('Erreur : '.$ex->getMessage());
                        }                        
                    ?>                    
                </div> <!--fermeture div article_Recherche_5000-->               

                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </div> <!--fermeture main2-->

            <footer>
                test footer
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>