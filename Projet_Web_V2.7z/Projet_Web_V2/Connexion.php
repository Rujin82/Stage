<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
include 'ConnexionClass.php';
session_start();

?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Connexion :</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>                
                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_connexion">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <div class="main2">
                <h1>Connexion : </h1>    
                <div class="formulaire_connexion">Formlaire de connexion :<br>
                    <form action="Connexion.php" method="post">                    
                        <p>Veuillez entrer les informations suivantes.</p>
                        <div class="connexion">
                            <input type="textarea" name="textarea_connexion_pseudo"> Pseudo</input><br><br>
                            <input type="password" name="textarea_connexion_mdp"> Mot de passe</input><br><br>                       
                            <button type="submit" name="bouton_valider_connexion" value="Submit">Valider</button>
                        </div> <!--fermeture div connexion-->
                    </form>
                </div> <!--fermeture div formulaire_connexion-->

                <div class="article_connexion_7000">
                    <?php
                        try {
                            if (isset($_POST['textarea_connexion_pseudo']) && $_POST['textarea_connexion_mdp'])
                            {
                                    $connexionUtilisateur = new ManagerClass($base);
                                    $connexion = new ConnexionClass();
                                    $connexion->setPseudoConnexion(htmlentities(addslashes($_POST['textarea_connexion_pseudo']), ENT_QUOTES));
                                    $connexion->setMdpConnexion(htmlentities(addslashes($_POST['textarea_connexion_mdp']), ENT_QUOTES));
                                    $connexionUtilisateur->ConnexionUtilisateur($base, $connexion);
                            } else {
                                echo '<br/>Veuillez remplir tous les champs.<br/>';
                            }
                        } 
                        catch (Exception $ex) 
                        {
                            echo '<br/>Erreur dans la fonction connexion.';
                            die('Erreur : '.$ex->getMessage());
                        }
                    ?>
                </div> <!--fermeture div article_connexion_7000-->

                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </div> <!--fermeture div main2-->

            <footer>
                test footer                
            </footer>

        </div> <!--fermeture div wrap-->
    </body>
</html>