<?php
require 'Manager/ConnexionBDD.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $_SESSION["Pseudo"];
}
?>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Accueil</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>
                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_index">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <aside>
                <form action="Recherche.php" method="post">
                    <div class="recherche">RECHERCHE :<br>
                        <div class="rech_radio">
                            <input type="radio" name="choix" value="Bouton_Radio_Faction" checked> Faction<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Territoire"> Territoire<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Declin"> Année de déclin
                        </div> <!--fermeture div rech_radio-->
                        <input type="textarea" name="textarea_recherche1"></input><br>
                        <button type="submit" name="valider1" value="Submit">Valider</button>
                    </div> <!--fermeture div recherche-->
                </form>

                <ul>
                    <li><strong><a href="#article_Accueil_2000">Les Clans Majeurs</a></strong></li>
                    <li><strong><a href="#article_Accueil_2100">Province d'origine</a></strong></li>
                    <li><strong><a href="#article_Accueil_2200">Date de décin</a></strong></li>
                    <li><strong><a href="#article_Accueil_2300">Tableau</a></strong></li>
                </ul>                
            </aside>

            <main>
                <h1>Page d'accueil</h1>                                        
                    <h2><a href="Faction.php">FACTION</a></h2>
                        <p>Vous trouverez sur cette page l'ensemble des factions répertoriées dans la base de données.</p><br>
                    
                    <h2><a href="Territoire.php">TERRITOIRE</a></h2>
                        <p>Vous trouverez sur cette page l'ensemble des régions du Japon de cette époque, 
                        ainsi que plus précisémment les régions d'origines des clans sélectionnés.
                        Toutefois ces régions peuvent relever plus de l'arbitraire au vue de la complexité
                        historique.</p><br>
                        
                    <h2><a href="Histoire.php">HISTOIRE</a></h2>
                        <p>Vous trouverez sur cette page quelques dates historiques marquantes de cette période du sengoku-jidai.
                            là encore une date plus au moins arbitraire a été prise pour chacun des clans.</p><br>

                <div class="article_Accueil_2000">
                    <h2 id="article_Accueil_2000">Les Clans Majeurs</h2>
                        <ul>
                            <li>Clan Chosokabe</li>
                            <li>Clan Date</li>
                            <li>Clan Hojo</li>
                            <li>Clan Mori</li>
                            <li>Clan Oda</li>
                            <li>Clan Shimazu</li>
                            <li>Clan Takeda</li>
                            <li>Clan Uesugi</li>
                        </ul>
                    <div class="up"><a href="#">(Up)</a></div>
                </div> <!--fermeture div article_Accueil_2000-->

                <div class="article_Accueil_2100">
                    <h2 id="article_Accueil_2100">Territoire</h2>                            
                        <h3>Chosokabe</h3>
                        <p>Province Tosa</p>

                        <h3>Date</h3>
                        <p>Province de Mutsu</p>

                        <h3>Hojo</h3>
                        <p>Province d'Ise</p>

                        <h3>Mori</h3>
                        <p>Province d'Aki</p>

                        <h3>Oda</h3>
                        <p>Province d'Owari</p>

                        <h3>Shimazu</h3>
                        <p>Province Satsuma et Osumi</p>

                        <h3>Takeda</h3>    
                        <p>Province Kai</p>

                        <h3>Uesugi</h3>
                        <p>Province Echigo</p>
                        <div class="up"><a href="#">(Up)</a></div>
                </div> <!--fermeture div article_Accueil_2100-->

                <div class="article_Accueil_2200">
                    <h2 id="article_Accueil_2200">Date de déclin</h2>                            
                        <h3>Chosokabe</h3>
                        <p>Date de déclin 1587</p>

                        <h3>Date</h3>
                        <p>Date de déclin 1590</p>

                        <h3>Hojo</h3>
                        <p>Date de déclin 1590</p>

                        <h3>Mori</h3>
                        <p>Date de déclin 1579</p>

                        <h3>Oda</h3>
                        <p>Date de déclin 1582</p>

                        <h3>Shimazu</h3>
                        <p>Date de déclin 1584</p>

                        <h3>Takeda</h3>    
                        <p>Date de déclin 1573</p>

                        <h3>Uesugi</h3>
                        <p>Date de déclin 1578</p>
                        <div class="up"><a href="#">(Up)</a></div>
                </div> <!--fermeture div article2200-->

                <div class="article_Accueil_2300">
                    <h2 id="article_Accueil_2300">tableau</h2>
                        <table>
                            <tr><th>
                                Clans
                            </th><th>
                                Provinces d'origines
                            </th><th>
                                Date de déclin
                            </th></tr><tr><td>
                                Chosokabe
                            </td><td>
                                Tosa
                            </td><td>
                                1587
                            </td></tr><tr><td>
                                Date
                            </td><td>
                                Mutsu
                            </td><td>
                                1590
                            </td></tr><tr><td>
                                Hojo
                            </td><td>
                                Ise
                            </td><td>
                                1590
                            </td></tr><tr><td>
                                Mori
                            </td><td>
                                Aki
                            </td><td>
                                1579
                            </td></tr><tr><td>
                                Oda
                            </td><td>
                                Owari
                            </td><td>
                                1582
                            </td></tr><tr><td>
                                Shimazu
                            </td><td>
                                Satsuma
                            </td><td>
                                1584
                            </td></tr><tr><td>
                                Takeda
                            </td><td>
                                Kai
                            </td><td>
                                1573
                            </td></tr><tr><td>
                                Uesugi
                            </td><td>
                                Echigo
                            </td><td>
                                1578
                            </td></tr>
                        </table>
                        <hr>

                        <div class='pageup'>
                            <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                        </div>

                </div> <!--fermeture div article_Accueil_2300-->
            </main>

            <footer>
                test footer

            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>