<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $_SESSION["Pseudo"];
}

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Deconnexion :</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>                
                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_deconnexion">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <div class="main2">
                <h1>Déconnexion : </h1>    

                <div class="article_connexion_7000">
                    <?php
                        try 
                        {
                            $deconnexionUtilisateur = new ManagerClass($base);
                            $deconnexionUtilisateur->DeconnexionUtilisateur($base);                                
                        } 
                        catch (Exception $ex) 
                        {
                            echo '<br/>Erreur dans la fonction déconnexion.';
                            die('Erreur : '.$ex->getMessage());
                        }
                    ?>
                </div> <!--fermeture div article_connexion_7000-->

            </div> <!--fermeture div main2-->

            <footer>
                test footer                
            </footer>

        </div> <!--fermeture div wrap-->
    </body>
</html>

