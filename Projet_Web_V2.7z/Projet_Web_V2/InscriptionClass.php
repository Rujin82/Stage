<?php
require 'Manager/ConnexionBDD.php';

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of InscriptionClass
 *
 * @author thork
 */
class InscriptionClass 
{
    // Déclaration des attributs
    private $_pseudo;
    private $_mdp;
    private $_email;
    private $_date_inscription;

    //accesseurs
    public function getPseudo() 
    {
        return $this->_pseudo; //retourne le _pseudo
    }
    
    public function setPseudo($_pseudo) 
    {
        $this->_pseudo = $_pseudo; //écrit dans l’attribut _pseudo
    }
    
    public function getMdp() 
    {
        return $this->_mdp; //retourne le _mdp
    }
    
    public function setMdp($_mdp) 
    {
        $this->_mdp = password_hash($_mdp, PASSWORD_DEFAULT); //écrit dans l’attribut _mdp
    }
    
    public function getEmail() 
    {
        return $this->_email; //retourne la _email
    }
    
    public function setEmail($_email) 
    {
        $this->_email = $_email; //écrit dans l’attribut _email
    }
    
    public function getDate_Inscription()
    {
        return $this->_date_inscription; //retourne la _date_inscription
    }
    
    public function setDate_Inscription($_date_inscription)
    {
        $_date_inscription = (string)$_date_inscription;
        $this->_date_inscription = $_date_inscription; //écrit dans l’attribut _date_inscription
    }
}
