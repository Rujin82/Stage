<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ManagerClass
 *
 * @author thork
 */
class ManagerClass 
{
    
    public function __construct($base) 
    {
        $this->base = $base;
    }
    
    /*recherches basiques dans la base de donnée suivant faction, territoire, date
    * et requetes préparées     */    
    public function Recherche($base) 
    {
        $_requete1 = (htmlentities(addslashes($_POST['textarea_recherche1']), ENT_QUOTES));
        if(!empty($_POST['textarea_recherche1']))
        {
            $_radio1 = $_POST["choix"];
            switch ($_radio1) 
            {
                case 'Bouton_Radio_Faction':
                    /*requete permettant d'obtenir le nom de la faction, 
                     * en fonction des caractères inscrit par l'utilisateur 
                     * peut importe leur place dans le nom.
                     */
                    $_recherche = $base->prepare("SELECT Nom_Faction FROM faction WHERE Nom_Faction LIKE ? ");
                    $_params1 = array("%$_requete1%");
                    $_recherche->execute($_params1);
                    $nom_colonne='Nom_Faction';
                    break;
                case 'Bouton_Radio_Territoire':
                    /*requete permettant d'obtenir le nom du territoire, 
                     * en fonction des caractères inscrit par l'utilisateur 
                     * peut importe leur place dans le nom.
                     */
                    $_recherche = $base->prepare("SELECT Nom_Territoire_Origine FROM territoire WHERE Nom_Territoire_Origine LIKE ? ");
                    $_params1 = array("%$_requete1%");
                    $_recherche->execute($_params1);
                    $nom_colonne='Nom_Territoire_Origine';
                    break;
                case 'Bouton_Radio_Declin':
                    /*requete permettant d'obtenir la date de déclin, 
                     * en fonction des caractères inscrit par l'utilisateur 
                     * peut importe leur place dans le nom.
                     */
                    $_recherche = $base->prepare("SELECT Date_de_declin_faction FROM periode_historique WHERE Date_de_declin_faction LIKE ? ");
                    $_params1 = array("%$_requete1%");
                    $_recherche->execute($_params1);
                    $nom_colonne='Date_de_declin_faction';                 
                    break;
                default :
                    echo "Aucune correspondance";
                    break;
            }
            echo 'Réponse à la recherche :'.'<br>';
            foreach ($_recherche as $ligne) 
            {
                echo $ligne[$nom_colonne].'<br/>';
            }
        } else {
            echo '<br/>Veuillez remplir le champ de recherche<br/>';
        }
    }
    
    /*Recherches avancées dans la base de donnée suivant faction, territoire, date 
     * avec jointure interne sur les 3 tables et requetes préparées*/     
    public function RechercheAvancee($base) 
    {      
        $_requete_avancee = (htmlentities(addslashes($_POST['textarea_recherche_avancee']), ENT_QUOTES));         
        $_radio_avancee = $_POST["choix"];
        switch ($_radio_avancee) 
        {
            case 'Bouton_Radio_Faction':
                /*requete permettant d'obtenir le nom de la faction,
                 * le nom du territoire et la date de déclin 
                 * en fonction du nom exact de la faction inscrit par l'utilisateur. 
                 */
                $_recherche_avancee = $base->prepare(
                "SELECT Nom_Faction, Nom_Territoire_Origine, Date_De_Declin_Faction "
                ."FROM faction "
                ."INNER JOIN territoire ON faction.Id_Faction = territoire.Id_Faction "
                ."INNER JOIN periode_historique ON faction.Id_Faction = periode_historique.Id_Faction "
                ."WHERE faction.Nom_Faction "
                ."LIKE ?");
                $_params_avancee = array("$_requete_avancee");
                $_recherche_avancee->execute($_params_avancee);
                while ($donnees = $_recherche_avancee->fetch()) 
                {
                    echo '<br/>Résultat de la recherche avancée :<br/>';
                    echo 'La faction : '. $donnees['Nom_Faction'].' au sein de la région '.$donnees['Nom_Territoire_Origine'];
                    echo ' qui a décliné à partir de l\'année '.$donnees['Date_De_Declin_Faction']. '.<br />';
                }
                break;
            case 'Bouton_Radio_Territoire':
                /*requete permettant d'obtenir le nom du territoire,
                 * le nom de la faction et la date de déclin 
                 * en fonction du nom exact du territoire inscrit par l'utilisateur. 
                 */
                $_recherche_avancee = $base->prepare(
                "SELECT Nom_Territoire_Origine, Nom_Faction, Date_De_Declin_Faction "
                ."FROM territoire "
                ."INNER JOIN faction ON territoire.Id_Faction =  faction.Id_Faction "
                ."INNER JOIN periode_historique ON territoire.Id_Faction = periode_historique.Id_Faction "
                ."WHERE territoire.Nom_Territoire_Origine "
                ."LIKE ?");
                $_params_avancee = array("$_requete_avancee");
                $_recherche_avancee->execute($_params_avancee);
                while ($donnees = $_recherche_avancee->fetch()) 
                {
                    echo '<br/>Résultat de la recherche avancée :<br/>';
                    echo 'Région : '. $donnees['Nom_Territoire_Origine'].' appartenant à la faction '.$donnees['Nom_Faction'];
                    echo ' qui a décliné à partir de l\'année '.$donnees['Date_De_Declin_Faction']. '.<br />';
                }
                break;
            case 'Bouton_Radio_Declin':
                /*requete permettant d'obtenir la date de declin,
                 * le nom de la faction et le nom du territoire 
                 * en fonction de la date exact de declin inscrit par l'utilisateur. 
                 */
                $_recherche_avancee = $base->prepare(
                "SELECT Date_De_Declin_Faction, Nom_Faction, Nom_Territoire_Origine "
                ."FROM periode_historique " 
                ."INNER JOIN faction ON faction.Id_Faction = periode_historique.Id_Faction "
                ."INNER JOIN territoire ON territoire.Id_Faction = periode_historique.Id_Faction "
                ."WHERE periode_historique.Date_De_Declin_Faction "
                ."LIKE ?");
                $_params_avancee = array("$_requete_avancee");
                $_recherche_avancee->execute($_params_avancee);
                while ($donnees = $_recherche_avancee->fetch()) 
                {
                    echo '<br/>Résultat de la recherche avancée :<br/>';
                    echo 'Date : '. $donnees['Date_De_Declin_Faction'].' de la faction '.$donnees['Nom_Faction'];
                    echo ' dans la région de '.$donnees['Nom_Territoire_Origine']. '.<br />';
                }
                break;
            default :
                echo "Aucune correspondance";
                break;
        }
    }

    /*inscription des utilisateurs dans la base de données*/
    public function NouveauUtilisateur($base, $inscription) 
    {
        /*requete permettant de vérifier la présence du pseudo dans la base de données.
         * En fonction du pseudo inscrit par l'utilisateur.  
         */
        $verif_dispo_pseudo = $base->prepare("SELECT Pseudo FROM utilisateur WHERE Pseudo = '" . $inscription->getPseudo() . "'");
        $verif_dispo_pseudo->execute();
        if ($verif_dispo_pseudo->fetch() == NULL) 
        {         
            /*requete permettant de vérifier la présence de l'email dans la base de données.
             * En fonction de l'email inscrit par l'utilisateur.  
             */
            $verif_dispo_email = $base->prepare("SELECT Email FROM utilisateur WHERE Email = '" . $inscription->getEmail() . "'");
            $verif_dispo_email->execute();
            if ($verif_dispo_email->fetch() == NULL) 
            {
                /*requete permettant d'insérer le pseudo, le mot de passe,
                 * l'email ainsi que la date d'inscription dans la base de données.
                 * En fonction des infos rentrées par l'utilisateur et de la date
                 * du serveur pour la date d'inscription.  
                 */
                $identifiant = $base->prepare( 
                "INSERT INTO utilisateur (Pseudo, Mot_De_Passe, Email, Date_Inscription)"
                ."VALUES ('" . $inscription->getPseudo() . "','" . $inscription->getMdp() . "','"
                . $inscription->getEmail() . "','" . $inscription->getDate_Inscription() . "')");
                $identifiant->execute();
                echo '<br/>L\'inscription a été validée.<br/>';
                echo '<br/>Vous pouvez désormais vous connecter.<br/>';
            } else {
                echo '<br/>L\'email est déjà pris.<br/>';
                echo '<br/>Veuillez choisir une autre adresse mail.<br/>';
            }
        } else {
            echo '<br/>Le pseudo est déjà pris.<br/>';
            echo '<br/>Veuillez choisir un autre pseudo.<br/>';
        }        
    }
    
    /*connexion des utilisateurs au site*/
    public function ConnexionUtilisateur($base, $connexion)
    {
        /*requete permettant de vérifier la présence du pseudo dans la base de données.
         * En fonction du pseudo inscrit par l'utilisateur.  
         */
        $identifiant_connexion = $base->prepare(
        "SELECT Mot_De_Passe FROM utilisateur WHERE Pseudo = '" . $connexion->getPseudoConnexion() . "'");
        $identifiant_connexion->execute();
        if ($identifiant_connexion->fetch() != NULL)
        {
            /*requete permettant de récupérer le mot de passe associé au pseudo 
             * dans la base de données. En fonction du pseudo inscrit par l'utilisateur.  
             */
            $recup_hash = "SELECT Mot_De_Passe FROM utilisateur WHERE Pseudo = '" . $connexion->getPseudoConnexion() . "'";
            foreach ($base->query($recup_hash) as $row) 
            {
                $hash = $row['Mot_De_Passe'];
                $verif_hash = new ConnexionClass($base);
                $verif_hash->setHash($hash);
                if (password_verify($connexion->getMdpConnexion(), $verif_hash->getHash()) == TRUE)
                {
                    echo '<br/>Vous êtes connecté<br/>';
                    echo '<br/>' . $connexion->getPseudoConnexion() . ' : est votre pseudo<br/>';
                    $_SESSION["Pseudo"] = $connexion->getPseudoConnexion();
                    header('Location: blog.php'); 
                    exit();                
                } else {
                    echo '<br/>Le mot de passe est invalide.<br/>';
                }
            }
        } else {
            echo '<br/>Aucune correspondance Pseudo.<br/>';
        }
    }
    
    /*déconnexion des utilisateurs au site*/
    public function DeconnexionUtilisateur($base)
    {
        $id_retrouve = NULL;
        session_destroy();
        echo '<br/>Vous êtes déconnecté<br/>';
        header('Location: index.php');
        exit();
    }
    
    /*fonctionalité permettant de créer 
     * de nouveaux messages dans la partie blog.*/
    public function AjoutBlog($base, $messagerie, $id_retrouve)
    {
        /*Recuperation de l'id utilisateur en fonction du pseudo enregistré dans $_SESSION*/
        $pseudo_du_message = $base->prepare(
        "SELECT Id_Utilisateur FROM utilisateur WHERE Pseudo = '" . $id_retrouve . "'");
        $pseudo_du_message->execute();
        while ($id_recupere = $pseudo_du_message->fetch()) 
        {
            $id_recupere_integer = (integer)$id_recupere[0];
            /*Insere dans la base de données la date du message, le message,
             * ainsi que l'id de l'utilisateur. En fonction du message écrit par l'utilisateur,
             * la date du serveur et le pseudo récupéré par $_SESSION.
             */
            $ajout_message = $base->prepare(
            "INSERT INTO blog (Date_Messages, Messages, Id_Utilisateur)"
            ."VALUES ('" . $messagerie->getDateMessage() . "','" . $messagerie->getMessage() . 
            "'," . $id_recupere_integer . ")");
            $ajout_message->execute();    
        }
    }
    
    /*fonctionnalité permettant d'afficher les messages
     * de la partie blog.*/
    public function getMessageParDate($base) 
    {
        $tableau_blog = array();
        $compteur_blog = 0;
        /*Recuperation du pseudo, date du message, message de la table blog,
         * dans l'ordre des messages les plus anciens au plus récents.
         */
        $resultat_blog = $this->base->prepare(
        "SELECT Pseudo, Date_Messages, Messages "
        ."FROM blog "
        ."INNER JOIN utilisateur ON blog.Id_Utilisateur = utilisateur.Id_Utilisateur "
        ."ORDER BY Date_Messages");
        $resultat_blog->execute();
        //fetch sur chaque ligne ramenée par la requête
        while ($ligne = $resultat_blog->fetch()) 
        {
            $blog = new BlogClass();
            $blog->setPseudoMessagerie($ligne['Pseudo']);
            $blog->setDateMessage($ligne['Date_Messages']);
            $blog->setMessage($ligne['Messages']);
            /*stockage de l’objet dans le tableau*/
            $tableau_blog[$compteur_blog] = $blog; 
            $compteur_blog++;
        }
        return $tableau_blog;
    }
    
    /*fonctionnalité permettant la création de personnage*/
    public function CreationPersonnage($base, $creation)
    {
        /*Verification de la presence de la faction dans la base de données*/
        $verif_faction = $base->prepare(
        "SELECT Nom_Faction FROM faction WHERE Nom_Faction = '" 
        .$creation->getFactionPersonnage() . "'");
        $verif_faction->execute();
        if ($verif_faction->fetch() != NULL) 
        {  
            /*Recuperation de l'id de la faction*/
            $recup_idfaction = $base->prepare(
            "SELECT Id_Faction FROM faction WHERE Nom_Faction = '" . $creation->getFactionPersonnage() . "'");
            $recup_idfaction->execute();
            $recup_idfaction_personnage = $recup_idfaction->fetch();
            $creationIdFaction = (integer)$recup_idfaction_personnage[0];
            if ($creation->getPseudoPersonnage() != NULL)
            {
                /*Recuperation de l'id de l'utilisateur*/
                $recup_idutilisateur = $base->prepare(
                "SELECT Id_Utilisateur FROM utilisateur WHERE Pseudo = '" . $creation->getPseudoPersonnage() . "'");
                $recup_idutilisateur->execute();
                $recup_idutilisateur_personnage = $recup_idutilisateur->fetch();
                $creationIdUtilisateur = (integer)$recup_idutilisateur_personnage[0];
                if ($creationIdUtilisateur != NULL)
                {
                    /*Verification de la disponibilite du nom et du prenom pour le personnage
                     * afin d'eviter les homonymes, doublons.
                     */
                    $verif_dispo_nom_prenom_personnage = $base->prepare(
                    "SELECT Nom_Personnages, Prenom_Personnages FROM personnages WHERE Nom_Personnages = '" 
                    .$creation->getNomPersonnage() . "' && Prenom_Personnages = '" . $creation->getPrenomPersonnage() . "'");
                    $verif_dispo_nom_prenom_personnage->execute();
                    $dispo_nom_prenom_personnage = $verif_dispo_nom_prenom_personnage->fetch();
                    if ($dispo_nom_prenom_personnage == NULL)
                    {
                        /*Inserer dans la base de donnees le nom du personnage, 
                         * le prenom du personnage, l'age du personnage,
                         * le nom de fichier de l'image du personnage,
                         * l'Id de l'utilisateur ainsi que l'id de la faction.
                         */
                        $realisationPersonnage = $base->prepare( 
                        "INSERT INTO personnages (Nom_Personnages, Prenom_Personnages, Sexe_Personnages,"
                        ."Age_Personnages, Image_Personnages, Id_Utilisateur, Id_Faction)"
                        ."VALUES ('" . $creation->getNomPersonnage() . "','" . $creation->getPrenomPersonnage() . "','"
                        .$creation->getSexePersonnage() . "'," . $creation->getAgePersonnage() . ",'"
                        .$creation->getImagePersonnage() . "'," . $creationIdUtilisateur . "," 
                        .$creationIdFaction . ")");
                        $realisationPersonnage->execute();
                        echo '<br/>La création du personnage a été validée.<br/>';
                    } else {
                        echo '<br/>Ce personnage existe déjà.<br/>';
                        echo '<br/>Veuillez renommer votre personnage.<br/>';
                    }
                }
            } else {
                echo '<br/>Problème de récupération du pseudo.<br/>';
            }            
        } else {
            echo '<br/>Aucune faction ne correspond à la base de données.<br/>';
            echo '<br/>Veuillez choisir une faction valide.<br/>';
        }
    }
    
    /*fonctionnalité permettant d'afficher les personnages
     * de l'utilisateur connecté.*/
    public function getPersonnagesParFaction($base) 
    {
        $tableau_personnages = array();
        $compteur_personnages = 0;
        /*Recuperation de l'ensemble des informations des differents personnages
         * cree par l'utilisateur par ordre de nom de famille.
         */
        $resultat_personnages = $this->base->prepare(
        "SELECT Image_Personnages, Nom_Personnages, Prenom_Personnages, Sexe_Personnages, "
        ."Age_Personnages, Nom_Faction, Nom_Territoire_Origine "
        ."FROM personnages "
        ."INNER JOIN faction ON personnages.Id_Faction = faction.Id_Faction "
        ."INNER JOIN territoire ON personnages.Id_Faction = territoire.Id_Faction "
        ."INNER JOIN utilisateur ON personnages.Id_Utilisateur = utilisateur.Id_Utilisateur "
        ."WHERE Pseudo = '" . $_SESSION["Pseudo"] . "' "
        ."ORDER BY Nom_Faction");
        $resultat_personnages->execute();
        //fetch sur chaque ligne ramenée par la requête
        while ($ligne = $resultat_personnages->fetch()) 
        {
            $personnages = new Creation_PersonnageClass();
            $personnages->setImagePersonnage($ligne['Image_Personnages']);
            $personnages->setNomPersonnage($ligne['Nom_Personnages']);
            $personnages->setPrenomPersonnage($ligne['Prenom_Personnages']);
            $personnages->setSexePersonnage($ligne['Sexe_Personnages']);
            $personnages->setAgePersonnage($ligne['Age_Personnages']);
            $personnages->setFactionPersonnage($ligne['Nom_Faction']);
            $personnages->setTerritoirePersonnage($ligne['Nom_Territoire_Origine']);
            /*stockage de l’objet dans le tableau*/
            $tableau_personnages[$compteur_personnages] = $personnages;
            $compteur_personnages++;
        }
        return $tableau_personnages;
    }
    
    /*Fonctionnalité permettant de modifier un personnage dans la base de données
    ayant été créé par ce même utilisateur */
    public function ModificationPersonnage($base, $modification)
    {
        /*Recupere l'ensemble des informations de l'utiisateur pour que celui-ci
         * puisse les modifier dans la base de donnees. En fonction du
         * nom et du prenom du personnage souhaite par l'utilisateur.
         */
        $selectionner_personnages_a_modifier = $this->base->prepare(
        "SELECT Image_Personnages, Nom_Personnages, Prenom_Personnages, Sexe_Personnages, "
        ."Age_Personnages, Nom_Faction "
        ."FROM personnages "
        ."INNER JOIN faction ON personnages.Id_Faction = faction.Id_Faction "
        ."INNER JOIN utilisateur ON personnages.Id_Utilisateur = utilisateur.Id_Utilisateur "
        ."WHERE Nom_Personnages = '" . $modification->getNomModifiePersonnage() . 
        "' && Prenom_Personnages = '" . $modification->getPrenomModifiePersonnage() . "' && Pseudo = '" . $_SESSION['Pseudo'] . "'");
        $selectionner_personnages_a_modifier->execute();
        if ($selectionner_personnages_a_modifier->fetch() != NULL)
        {
            /*Recupere l'id de l'utilisateur en fonction du pseudo inscrit dans 
             * $_SESSION.
             */
            $recupIdPseudo = "SELECT Id_Utilisateur FROM utilisateur WHERE Pseudo = '" . $_SESSION['Pseudo'] . "'";
            foreach ($base->query($recupIdPseudo) as $row) 
            {
                $IdPseudo = $row['Id_Utilisateur'];
                $integration_IdPseudo = new ConnexionClass($base);
                $integration_IdPseudo->setIdPseudo($IdPseudo);
                /*Recupere l'id de la faction en fonction de ce que l'utilisateur a inscrit*/
                $recupIdFaction = "SELECT Id_Faction FROM faction WHERE Nom_Faction = '" 
                . $modification->getFactionModifiePersonnage() . "'";
                foreach ($base->query($recupIdFaction) as $row2)
                {
                    $IdFaction = $row2['Id_Faction'];
                    $integration_IdFaction = new Modification_PersonnageClass($base);
                    $integration_IdFaction->setIdFaction($IdFaction);
                    /*Ecrase et enregistre l'ensemble des informations sur le personnage*/
                    $realisationPersonnage = $base->prepare(
                    "UPDATE personnages "
                    ."SET Nom_Personnages = '" . $modification->getNomModifiePersonnage() . "', "
                    ."Prenom_Personnages = '" . $modification->getPrenomModifiePersonnage() . "', "
                    ."Sexe_Personnages = '" . $modification->getSexeModifiePersonnage() . "', "
                    ."Age_Personnages = " . $modification->getAgeModifiePersonnage() . ", "
                    ."Image_Personnages = '" . $modification->getImageModifiePersonnage() . "', "
                    ."Id_Faction = " . $integration_IdFaction->getIdFaction() . " "
                    ."WHERE Id_Utilisateur = " . $integration_IdPseudo->getIdPseudo() . "");
                    $realisationPersonnage->execute();
                    echo '<br/>La modification du personnage a été validée.<br/>';
                }
            }
        }
    }
    
    /*Fonctionnalité permettant de supprimer un personnage dans la base de données
    ayant été créé par ce même utilisateur */
    public function SupprimerPersonnages($base, $supprimer) 
    {
        /*Verification de l'existence du personnage avec son nom, prenom,
         * associe au bon utilisateur.
         */
        $verif_existance_personnage = $this->base->prepare(
        "SELECT Nom_Personnages, Prenom_Personnages "
        ."FROM personnages "
        ."INNER JOIN utilisateur ON personnages.Id_Utilisateur = utilisateur.Id_Utilisateur "
        ."WHERE Nom_Personnages = '" . $supprimer->getNomPersonnage() . 
        "' && Prenom_Personnages = '" . $supprimer->getPrenomPersonnage() . "' && Pseudo = '" . $_SESSION['Pseudo'] . "'");
        $verif_existance_personnage->execute();
        if ($verif_existance_personnage->fetch() != NULL)
        {   
            /*Suppression du personnage si ce personnage existe et a bien ete
             * cree par l'utilisateur.
             */
            $supprimer_personnages = $this->base->prepare(
            "DELETE FROM personnages WHERE Nom_Personnages = '" . $supprimer->getNomPersonnage() . 
            "' && Prenom_Personnages = '" . $supprimer->getPrenomPersonnage() . "'");
            $supprimer_personnages->execute();
            /*Verification de la suppression du personnage demande par
             *  l'utilisateur.
             */
            $verif_suppression = $this->base->prepare(
            "SELECT Nom_Personnages, Prenom_Personnages "
            ."FROM personnages "
            ."INNER JOIN utilisateur ON personnages.Id_Utilisateur = utilisateur.Id_Utilisateur "
            ."WHERE Nom_Personnages = '" . $supprimer->getNomPersonnage() . 
            "' && Prenom_Personnages = '" . $supprimer->getPrenomPersonnage() . 
            "' && Pseudo = '" . $_SESSION['Pseudo'] . "'");
            $verif_suppression->execute();
            if ($verif_suppression->fetch() == NULL)
            {
                header('Location: Fiche_Personnage.php'); 
                exit();                
            } else {
                echo '<br/>La suppression n\'a pas été possible.<br/>';
            }
        } else {
            echo '<br/>Problème lors de l\'envoi de l\'identifiant.<br/>';
        }
    }
}