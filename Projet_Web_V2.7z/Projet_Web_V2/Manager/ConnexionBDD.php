<?php
    //Connexion à la base de données
    $base = new PDO('mysql:host=127.0.0.1;dbname=projetwebv2', 'root', '');
    $base->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
?>