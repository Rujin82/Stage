<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
include 'BlogClass.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $id_retrouve = $_SESSION["Pseudo"];
}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Ajout_Blog</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>                
                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_ajout_blog">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>

            <div class="main2">
                <h1>Création d'un nouveau message : </h1>

                <div class="article_Ajout_blog_9000">
                    <form action="Ajout_Blog.php" method="post">
                        <p>Nouveau Message :</p><br>
                        <input type="textarea" name="textarea_Ajout_Blog_Message"></input><br><br>
                        <div class='Ajout_Blog_Validation'>
                            <a href="#"><button type='submit' name='Bouton_Ajout_Blog_Valider'>Valider</button></a>
                        </div>
                    </form>                    
                </div> <!--fermeture div article_Ajout_blog_9000-->
                
                <?php
                    try {
                        if (isset($_POST['textarea_Ajout_Blog_Message']))
                        {
                            $ajoutBlog = new ManagerClass($base);
                            $messagerie = new BlogClass();
                            $messagerie->setMessage(htmlentities(addslashes($_POST['textarea_Ajout_Blog_Message']), ENT_QUOTES));
                            $messagerie->setDateMessage(date('Y-m-d H:i:s'));
                            $ajoutBlog->AjoutBlog($base, $messagerie, $id_retrouve);
                        } else {
                            echo '<br/>Veuillez remplir tous les champs.<br/>';  
                        }
                    } 
                    catch (Exception $ex) 
                    {
                        echo '<br/>Erreur dans la fonction ajout de message du blog.';
                        die('Erreur : '.$ex->getMessage());
                    }                
                ?>
                
                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </div> <!--fermeture div main2-->

            <footer>
                test footer                
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>
