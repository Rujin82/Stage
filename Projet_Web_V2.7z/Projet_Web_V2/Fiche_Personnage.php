<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
include 'Creation_PersonnageClass.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $_SESSION["Pseudo"];
}

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Creation_Personnage</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>                
                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Blog.php">BLOG</a></strong></li>';
                        echo '<li><strong><a href="Creation_Personnage.php">CREATION DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_fiche_personnage">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>
            </nav>
            
            <aside>
                <form action="Recherche.php" method="post">
                    <div class="recherche">RECHERCHE :<br>
                        <div class="rech_radio">
                            <input type="radio" name="choix" value="Bouton_Radio_Faction" checked> Faction<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Territoire"> Territoire<br>
                            <input type="radio" name="choix" value="Bouton_Radio_Declin"> Année de déclin
                        </div> <!--fermeture div rech_radio-->
                            <input type="textarea" name="textarea_recherche1"></input><br>
                        <button type="submit" name="valider1" value="Submit">Valider</button>
                    </div> <!--fermeture div recherche-->
                </form>               
            </aside>

            <main>
                <h1>Fiche de Personnage : </h1>

                <div class="article_Fiche_personnage_11000">

                    <?php
                        try 
                        {
                            $recupPersonnages = new ManagerClass($base);
                            $tableau_retour_personnages = $recupPersonnages->getPersonnagesParFaction($base);
                            if (empty($tableau_retour_personnages))
                            {
                                echo 'Aucun personnage de retrouvé.';
                            } else {
                                foreach ($tableau_retour_personnages as $valeur) 
                                {
                                    echo "<p>" . $valeur->getImagePersonnage() . "</p>";
                                    echo "<p>Nom : " . $valeur->getNomPersonnage() . "</p>";
                                    echo "<p>Prénom : " . $valeur->getPrenomPersonnage() . "<p>";
                                    echo "<p>Genre : " . $valeur->getSexePersonnage() . "<p>";
                                    echo "<p>Age : " . $valeur->getAgePersonnage() . "<p>";
                                    echo "<p>Faction : " . $valeur->getFactionPersonnage() . "<p>";
                                    echo "<p>Territoire : " . $valeur->getTerritoirePersonnage() . "<p>";
                                    echo "<hr />";
                                }
                            }                           
                        } catch (Exception $ex) {
                            echo '<br/>Erreur dans la fonction affichage des personnages.';
                            die('Erreur : '.$ex->getMessage());
                        }
                    ?>
                    <p>Gérer vos personnages : </p>
                    <a href="Creation_Personnage.php"><button type="submit" name='Bouton_Fiche_Personnage_Creation'>Creation</button></a>
                    <a href='Modification_Personnage.php'><button type= 'submit' name='bouton_modifier_fiche_personnage'>Modifier</button></a>
                    <a href='Supprimer_Personnage.php'><button type= 'submit' name='Bouton_Supprimer_Fiche_Personnage'>Supprimer</button></a>
                </div> <!--fermeture div article_Creation_personnage_10000-->
                <hr>

                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </main>

            <footer>
                test footer                
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>