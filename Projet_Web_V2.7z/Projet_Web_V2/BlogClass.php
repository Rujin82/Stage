<?php
require 'Manager/ConnexionBDD.php';

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BlogClass
 *
 * @author thork
 */
class BlogClass 
{    
    // Déclaration des attributs
    private $_message;
    private $_date_message;
    private $_pseudo_messagerie;

    //accesseurs
    public function getMessage() 
    {
        return $this->_message; //retourne le _message
    }
    
    public function setMessage($_message) 
    {
        $this->_message = $_message; //écrit dans l’attribut _message
    }
    
    public function getDateMessage()
    {
        return $this->_date_message; //retourne la _date_message
    }
    
    public function setDateMessage($_date_message)
    {
        $_date_message = (string)$_date_message;
        $this->_date_message = $_date_message; //écrit dans l’attribut _date_message
    }
    
    public function getPseudoMessagerie()
    {
        return $this->_pseudo_messagerie; //retourne le _pseudo_messagerie
    }
    
    public function setPseudoMessagerie($_pseudo_messagerie)
    {
        $this->_pseudo_messagerie = $_pseudo_messagerie;
    }
}

