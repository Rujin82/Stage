<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Creation_PersonnageClass
 *
 * @author thork
 */
class Creation_PersonnageClass 
{
    //attributs
    private $_nom_personnage;
    private $_prenom_personnage;
    private $_sexe_personnage;
    private $_age_personnage;
    private $_faction_personnage;
    private $_image_personnage;
    private $_pseudo_personnage;
    private $_territoire_personnage;
    private $_id_personnage;
    
    //accesseurs
    public function getNomPersonnage() 
    {
        return $this->_nom_personnage;
    }
    
    public function setNomPersonnage($_nom_personnage) 
    {
        $this->_nom_personnage = $_nom_personnage;
    }
    
    public function getPrenomPersonnage() 
    {
        return $this->_prenom_personnage;
    }
    
    public function setPrenomPersonnage($_prenom_personnage) 
    {
        $this->_prenom_personnage = $_prenom_personnage;
    }
    
    public function getSexePersonnage() 
    {
        return $this->_sexe_personnage;
    }
    
    public function setSexePersonnage($_sexe_personnage) 
    {
        $this->_sexe_personnage = $_sexe_personnage;
    }
    
    public function getAgePersonnage() 
    {
        return $this->_age_personnage;
    }
    
    public function setAgePersonnage($_age_personnage) 
    {
        if (($_age_personnage > 4) && ($_age_personnage < 110))
        {
            $this->_age_personnage = (integer)$_age_personnage;
        } else {            
            $_age_personnage = NULL;
            $this->_age_personnage = (integer)$_age_personnage;
        }
    }   
    
    public function getImagePersonnage()
    {
        return $this->_image_personnage;
    }
    
    public function setImagePersonnage($_image_personnage)
    {
        $this->_image_personnage = $_image_personnage;
    }
    
    public function getPseudoPersonnage()
    {
        return $this->_pseudo_personnage;
    }
    
    public function setPseudoPersonnage($_pseudo_personnage)
    {
        $this->_pseudo_personnage = $_pseudo_personnage;
    }
    
        public function getFactionPersonnage()
    {
        return $this->_faction_personnage;
    }
    
    public function setFactionPersonnage($_faction_personnage)
    {
        $this->_faction_personnage = $_faction_personnage;
    }
    
    public function getTerritoirePersonnage()
    {
        return $this->_territoire_personnage;
    }
    
    public function setTerritoirePersonnage($_territoire_personnage)
    {
        $this->_territoire_personnage = $_territoire_personnage;
    }
    
    public function getIdPersonnage()
    {
        return $this->_id_personnage;
    }
    
    public function setIdPersonnage($_id_personnage)
    {
        $this->_id_personnage = $_id_personnage;
    }
}
