<?php
require 'Manager/ConnexionBDD.php';
include 'Manager/ManagerClass.php';
include 'BlogClass.php';
session_start();
if (isset($_SESSION["Pseudo"]))
{
    $_SESSION["Pseudo"];
}
?>

<html lang="fr">
    <head>
        <meta charset="utf-8">
        <Title>Blog</Title>
        <link rel="stylesheet" type="text/css" href="Reset.css">
        <link rel="stylesheet" type="text/css" href="Responsive.css">
    </head>
    <body>
        <div class='wrap'>

            <header>
                test header
            </header>

            <nav>                
                <ul>
                    <?php
                    if (isset($_SESSION["Pseudo"]))
                    { 
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Ajout_Blog.php">REPONDRE</a></strong></li>';
                        echo '<li><strong><a href="Fiche_Personnage.php">FICHE DE PERSONNAGES</a></strong></li>';
                        echo '<li><strong><a href="Deconnexion.php"><button type= "submit" name="bouton_deconnexion_blog">'
                        . 'Déconnexion : '. $_SESSION["Pseudo"] . '</button></a></strong></li>';
                    } else {
                        echo '<li><strong><a href="Index.php">ACCUEIL</a></strong></li>';
                        echo '<li><strong><a href="Inscription.php">INSCRIPTION</a></strong></li>';
                        echo '<li><strong><a href="Connexion.php">CONNEXION</a></strong></li>';
                    }
                    ?>
                </ul>                
            </nav>

            <div class="main2">
                <h1>Blog : </h1>

                <div class="article_blog_8000">
                    <hr>
                    <?php
                        try 
                        {
                            $recupMessages = new ManagerClass($base);
                            $tableau_retour_blog = $recupMessages->getMessageParDate($base);
                            if (empty($tableau_retour_blog))
                            {
                                echo 'Aucun message.';
                            } else {
                                foreach ($tableau_retour_blog as $valeur) 
                                {
                                    echo "<h3>" . $valeur->getPseudoMessagerie() . "</h3>";
                                    echo "<h4>" . $valeur->getDateMessage() . "</h4>";
                                    echo "<div style=’width:400px’>";
                                    echo "<p>" . $valeur->getMessage() . "<p></div>";
                                    echo "<hr />";
                                }
                            }                           
                        } catch (Exception $ex) {
                            echo '<br/>Erreur dans la fonction affichage du blog.';
                            die('Erreur : '.$ex->getMessage());
                        }
                    ?>
                    <div class='Bouton_Blog_Repondre'>
                        <a href="Ajout_Blog.php"><button type='submit' name='Bouton_Blog_Repondre'>Répondre</button></a>
                    </div>
                </div> <!--fermeture div article_blog_8000-->             
                
                <div class='pageup'>
                    <a href="#"><button type='submit' name='pageup'>Haut de la Page</button></a>
                </div>
            </div> <!--fermeture div main2-->

            <footer>
                test footer                
            </footer>

        </div> <!-- fin wrap -->
    </body>
</html>